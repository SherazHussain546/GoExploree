#!/bin/bash

# Script to prepare Android icons from a source PNG file
# Usage: ./prepare-android-icons.sh generated-icon.png

SOURCE_ICON=$1

if [ -z "$SOURCE_ICON" ]; then
  echo "Please provide a source icon file"
  echo "Usage: ./prepare-android-icons.sh generated-icon.png"
  exit 1
fi

if [ ! -f "$SOURCE_ICON" ]; then
  echo "Source icon file not found: $SOURCE_ICON"
  exit 1
fi

# Create directories if they don't exist
mkdir -p android/app/src/main/res/mipmap-mdpi
mkdir -p android/app/src/main/res/mipmap-hdpi
mkdir -p android/app/src/main/res/mipmap-xhdpi
mkdir -p android/app/src/main/res/mipmap-xxhdpi
mkdir -p android/app/src/main/res/mipmap-xxxhdpi

# Resize the icon to different resolutions
convert "$SOURCE_ICON" -resize 48x48 android/app/src/main/res/mipmap-mdpi/ic_launcher.png
convert "$SOURCE_ICON" -resize 72x72 android/app/src/main/res/mipmap-hdpi/ic_launcher.png
convert "$SOURCE_ICON" -resize 96x96 android/app/src/main/res/mipmap-xhdpi/ic_launcher.png
convert "$SOURCE_ICON" -resize 144x144 android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png
convert "$SOURCE_ICON" -resize 192x192 android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png

# Create round icons
convert "$SOURCE_ICON" -resize 48x48 android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png
convert "$SOURCE_ICON" -resize 72x72 android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png
convert "$SOURCE_ICON" -resize 96x96 android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png
convert "$SOURCE_ICON" -resize 144x144 android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png
convert "$SOURCE_ICON" -resize 192x192 android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png

# Create adaptive icons background
mkdir -p android/app/src/main/res/drawable
convert "$SOURCE_ICON" -resize 432x432 -gravity center -background "#4C6EF5" -extent 432x432 android/app/src/main/res/drawable/ic_launcher_background.png

# Create foreground icon (the house and pin)
convert "$SOURCE_ICON" -resize 324x324 android/app/src/main/res/drawable/ic_launcher_foreground.png

echo "Android icons generated successfully!"