import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.goexploree.app',
  appName: 'GoExploree',
  webDir: 'www',
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      launchAutoHide: true,
      backgroundColor: "#4C6EF5",
      androidSplashResourceName: "splash",
      splashFullScreen: true,
      splashImmersive: true
    }
  },
  server: {
    androidScheme: 'https'
  },
  android: {
    buildOptions: {
      keystorePath: undefined,
      keystoreAlias: undefined,
      releaseType: "APK"
    }
  }
};

export default config;
