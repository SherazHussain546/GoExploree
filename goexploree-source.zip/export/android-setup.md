# Setting Up Android Development Environment

This guide will help you set up everything needed to build the GoExploree app for Android.

## Prerequisites

1. **Java Development Kit (JDK) 11 or newer**
   - Download from: [AdoptOpenJDK](https://adoptopenjdk.net/)
   - Set `JAVA_HOME` environment variable

2. **Android Studio**
   - Download from: [Android Studio](https://developer.android.com/studio)
   - During installation, make sure to select:
     - Android SDK
     - Android SDK Platform
     - Android Virtual Device (for testing)

3. **Android SDK**
   - Open Android Studio → Settings → Appearance & Behavior → System Settings → Android SDK
   - Install Android 13 (API Level 33) or higher
   - Install Android SDK Build-Tools
   - Install Android SDK Command-line Tools
   - Install Android SDK Platform-Tools

## Environment Variables Setup

Set the following environment variables:

- `ANDROID_HOME`: Path to Android SDK (e.g., `C:\Users\username\AppData\Local\Android\Sdk` on Windows)
- `PATH`: Add `%ANDROID_HOME%\platform-tools` and `%ANDROID_HOME%\tools` to your PATH

## Project Setup

1. Extract the `goexploree-android.zip` file
2. Open Android Studio
3. Select "Open an Existing Project"
4. Browse to and select the extracted folder

## Building from Source

If you prefer to build from scratch rather than using the Android package:

1. Extract `goexploree-source.zip`
2. Install Node.js and npm
3. Run `npm install` to install dependencies
4. Run `npm run build --prod` to build the web app
5. Install Ionic CLI: `npm install -g @ionic/cli`
6. Add Capacitor Android platform: `ionic capacitor add android`
7. Copy the web assets to Android: `ionic capacitor copy android`
8. Open in Android Studio: `ionic capacitor open android`

## Common Issues

### Gradle Sync Failed
- Make sure you have internet connection for Gradle to download dependencies
- Check if your firewall is blocking Gradle
- Try using "File > Invalidate Caches / Restart" in Android Studio

### Android SDK Location Not Found
- Create a `local.properties` file in the Android project root
- Add `sdk.dir=/path/to/your/Android/Sdk`

### Build Failed
- Check Gradle Console in Android Studio for specific errors
- Make sure you have the right JDK version (11+)
- Check if you have enough disk space

## Testing on Device

1. Enable "Developer options" on your Android device
   - Go to Settings > About phone
   - Tap "Build number" 7 times to unlock Developer options
2. Enable "USB debugging" in Developer options
3. Connect your device via USB
4. Select your device in Android Studio and click Run