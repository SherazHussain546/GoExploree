# GoExploree App Screens

This document provides an overview of the main screens in the GoExploree app.

## Home Screen

The home screen displays featured properties and search functionality.

Key components:
- Search bar at the top
- Featured properties carousel
- Property list with filtering options
- Navigation menu for other sections

## Property Details Screen

This screen displays detailed information about a selected property.

Key components:
- Property image gallery
- Price and key details (bedrooms, bathrooms, area)
- Full description
- Location map
- Features list
- Contact/Book Viewing button

## Booking Screen

The booking screen allows users to schedule a property viewing.

Key components:
- Property summary
- Date picker
- Time slot selector
- Contact information form
- Notes/questions field
- Submit button

## Profile Screen

The profile screen displays user information and bookings.

Key components:
- User photo and information
- Edit profile option
- Bookings list/history
- Favorites list
- Account settings

## Add Property Screen

This screen allows property owners to list a new property.

Key components:
- Property details form
- Image upload
- Location picker with map
- Features checklist
- Price and availability settings
- Submit button

## Login/Register Screens

These screens handle user authentication.

Key components:
- Email/password fields
- Social login options (Google)
- Registration form
- Password reset functionality

## User Flow Diagram

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│             │     │             │     │             │
│  Login/     │────▶│  Home       │────▶│  Property   │
│  Register   │     │  Screen     │     │  Details    │
│             │     │             │     │             │
└─────────────┘     └─────────────┘     └──────┬──────┘
                          ▲                    │
                          │                    │
                          │                    ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│             │     │             │     │             │
│  Profile    │────▶│  Favorites  │     │  Book       │
│  Screen     │     │  List       │     │  Viewing    │
│             │     │             │     │             │
└──────┬──────┘     └─────────────┘     └─────────────┘
       │
       │
       ▼
┌─────────────┐     ┌─────────────┐
│             │     │             │
│  My         │────▶│  Add New    │
│  Properties │     │  Property   │
│             │     │             │
└─────────────┘     └─────────────┘
```

## Screen Transitions

The app uses Ionic page transitions:
- Standard navigation stack for page history
- Modal presentations for forms and details
- Side menu for main navigation
- Tab-based navigation in profile section

## Responsive Behavior

All screens are designed to be responsive:
- Adapts to different screen sizes (phone, tablet)
- Landscape and portrait orientation support
- Touch-friendly controls for mobile
- Desktop friendly with mouse support