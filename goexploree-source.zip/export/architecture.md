# GoExploree App Architecture

This document provides an overview of the GoExploree app architecture and its components.

## System Architecture

GoExploree follows a client-server architecture with the following key components:

```
┌────────────────┐     ┌───────────────┐     ┌───────────────┐
│                │     │               │     │               │
│  Ionic Angular │────▶│ Express API   │────▶│ PostgreSQL DB │
│  Mobile App    │     │ Server        │     │               │
│                │     │               │     │               │
└────────────────┘     └───────────────┘     └───────────────┘
        │                      │                     
        │                      │                     
        ▼                      ▼                     
┌────────────────┐     ┌───────────────┐            
│                │     │               │            
│  Firebase      │     │ SendGrid      │            
│  Authentication│     │ Email Service │            
│                │     │               │            
└────────────────┘     └───────────────┘            
```

## Front-end Architecture

The front-end is built with Ionic Angular and follows these design patterns:

1. **Service-based Architecture**: Each feature has its own service (PropertyService, BookingService, etc.)
2. **Component-based Design**: UI components are modular and reusable
3. **Reactive Programming**: Uses RxJS for state management and data flow
4. **Lazy Loading**: Feature modules are loaded on demand

### Key Modules

- `app.module.ts`: Core module with app-wide providers
- Feature modules:
  - Home
  - Property Details
  - Property Add/Edit
  - Booking
  - Profile
  - Authentication (Login/Register)

### Services

- `auth.service.ts`: Handles authentication with Firebase
- `property.service.ts`: Property CRUD operations
- `booking.service.ts`: Booking management
- `email.service.ts`: Email notifications
- `storage.service.ts`: Local data persistence

## Backend Architecture

The backend consists of:

1. **Express API Server**: Handles API requests from the front-end
2. **PostgreSQL Database**: Stores application data
3. **Drizzle ORM**: Object-Relational Mapping for database operations

### Database Schema

The database follows a relational schema with these main entities:

- `users`: User accounts and profiles
- `properties`: Real estate property listings
- `bookings`: Property viewing appointments
- `favorites`: User's favorite properties

## Authentication Flow

1. User registers/signs in through Firebase Authentication
2. Auth service stores user token in secure storage
3. Token is included in API requests to the server
4. Server validates token and identifies the user

## Data Flow

### Property Browsing
1. User navigates to home page
2. App fetches properties from API
3. Properties are displayed in a list/grid view
4. User can filter, search, or view property details

### Booking Flow
1. User selects a property
2. User inputs booking details (date, time, etc.)
3. App sends booking request to server
4. Server creates booking record
5. Email notification is sent to property owner and user

## Mobile Optimizations

- **Offline Support**: Critical data is cached locally
- **Responsive Design**: Adapts to different screen sizes
- **Performance**: Lazy loading, code splitting, and image optimization
- **Native Features**: Camera access, geolocation, push notifications

## Security Measures

- JWT-based authentication
- Input validation
- SQL injection prevention through ORM
- Content Security Policy
- Secure data storage

## Deployment Architecture

The app can be deployed in multiple ways:

1. **Web App**: Hosted as a progressive web app
2. **Android App**: Packaged as an APK
3. **iOS App**: Packaged as an IPA (requires Apple Developer account)

## Future Expansion

The architecture supports future expansion through:

1. Modular design for adding new features
2. Scalable backend for increased user load
3. Standardized API contracts for third-party integrations