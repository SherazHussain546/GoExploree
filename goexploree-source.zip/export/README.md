# GoExploree - Real Estate Mobile App

GoExploree is a comprehensive real estate mobile application built with Ionic Angular that allows users to browse, search, and book property viewings.

## Features

- User authentication with Firebase
- Property browsing and search functionality
- Property details with map integration
- Booking system for property viewings
- User profile management
- Favorite properties
- Real-time notifications
- Mobile-optimized UI/UX

## Project Structure

- `src/app/` - Main application code
  - `services/` - API services, authentication, data handling
  - `models/` - Data models
  - `guards/` - Authentication guards
  - Feature modules (home, login, property-details, etc.)
- `shared/` - Shared code including database schema
- `android/` - Android platform-specific files

## Building the APK

### Prerequisites
- Node.js 16+
- Android Studio
- Java Development Kit (JDK) 11+
- Android SDK

### Steps to build the APK

1. Extract the project source
2. Install dependencies:
   ```
   npm install
   ```
3. Build the project:
   ```
   npm run build --prod
   ```
4. Add Android platform (if not already added):
   ```
   npx ionic cap add android
   ```
5. Sync the project:
   ```
   npx ionic cap sync android
   ```
6. Open in Android Studio:
   ```
   npx ionic cap open android
   ```
7. From Android Studio, go to Build > Build Bundle(s) / APK(s) > Build APK(s)

## Environment Setup

The app requires the following environment variables:

- Firebase configuration:
  - `VITE_FIREBASE_API_KEY`
  - `VITE_FIREBASE_PROJECT_ID`
  - `VITE_FIREBASE_APP_ID`
- Google Maps API:
  - `GOOGLE_MAPS_API_KEY`
- Database connection:
  - `DATABASE_URL`
- Zylalabs API (optional for property data):
  - API key for property data

## Mobile-Specific Optimizations

The app includes mobile-specific optimizations:
- Adaptive UI for different screen sizes
- Touch-friendly controls
- Offline storage capabilities
- Native device integrations via Capacitor

## Deployment

For production deployment:
1. Create a signed APK in Android Studio
2. Follow the Play Store submission guidelines

## Additional Resources

- [Ionic Framework Documentation](https://ionicframework.com/docs)
- [Capacitor Documentation](https://capacitorjs.com/docs)
- [Firebase Documentation](https://firebase.google.com/docs)