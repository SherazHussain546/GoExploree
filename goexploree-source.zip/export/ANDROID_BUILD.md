# Building GoExploree Android APK

This guide provides detailed instructions for building the GoExploree app into an Android APK using Android Studio.

## Prerequisites

- Android Studio (latest version recommended)
- JDK 11 or higher
- Android SDK (API level 33 or higher recommended)

## Import Project

1. Extract the `goexploree-android.zip` file to a directory on your computer
2. Open Android Studio
3. Select "Open an Existing Project"
4. Browse to the extracted directory and select it
5. Allow Gradle sync to complete

## Configure Signing

1. In Android Studio, go to `Build > Generate Signed Bundle/APK`
2. Select "APK" option
3. Create a new keystore or use an existing one:
   - If creating new: Fill in the form with keystore path, password, alias and key password
   - If using existing: Browse to your keystore file and enter your passwords
4. Click "Next"

## Build Configuration

1. Select "release" build variant
2. Check both "V1 (Jar Signature)" and "V2 (Full APK Signature)"
3. Click "Finish"

## Build Output

The APK will be generated in:
```
[project-dir]/app/release/app-release.apk
```

## Testing the APK

1. Connect an Android device via USB with developer options and USB debugging enabled
2. Install the APK by:
   - Drag and drop the APK file onto the device
   - Use ADB: `adb install app-release.apk`
   - Use Android Studio's "Run" function on a connected device

## Common Issues

### Missing local.properties
If you get an error about missing local.properties, create this file in the project root with:
```
sdk.dir=/path/to/your/Android/Sdk
```

### Gradle Version
If you get Gradle sync issues, use the recommended Gradle version in the project.

### Firebase Configuration
Make sure your Firebase configuration is properly set up in the app by:
1. Creating a Firebase project in the Firebase Console
2. Adding an Android app with your package name
3. Downloading the `google-services.json` file
4. Placing it in the `app/` directory

## Environment Variables

Make sure your app has access to all necessary API keys by setting them in `environment.ts` and `environment.prod.ts` files before building.

## Distribution

Once you've built your APK, you can:
1. Distribute it directly as an APK file
2. Upload it to the Google Play Store through the Play Console
3. Use a third-party distribution platform like Firebase App Distribution