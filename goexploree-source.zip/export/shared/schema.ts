import { relations, InferModel } from 'drizzle-orm';
import { pgTable, serial, varchar, text, integer, timestamp, boolean, json } from 'drizzle-orm/pg-core';

// Users Table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: varchar('uid', { length: 255 }).notNull().unique(),
  email: varchar('email', { length: 255 }).notNull().unique(),
  displayName: varchar('display_name', { length: 255 }),
  photoURL: text('photo_url'),
  phoneNumber: varchar('phone_number', { length: 20 }),
  isOwner: boolean('is_owner').default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// Properties Table
export const properties = pgTable('properties', {
  id: serial('id').primaryKey(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description').notNull(),
  price: integer('price').notNull(),
  location: varchar('location', { length: 255 }).notNull(),
  imageUrl: text('image_url'),
  latitude: varchar('latitude', { length: 20 }),
  longitude: varchar('longitude', { length: 20 }),
  bedrooms: integer('bedrooms'),
  bathrooms: integer('bathrooms'),
  area: integer('area'),
  features: json('features'),
  ownerId: varchar('owner_id', { length: 255 }).notNull(),
  ownerName: varchar('owner_name', { length: 255 }),
  ownerEmail: varchar('owner_email', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// Bookings Table
export const bookings = pgTable('bookings', {
  id: serial('id').primaryKey(),
  propertyId: integer('property_id').notNull(),
  propertyTitle: varchar('property_title', { length: 255 }),
  propertyImage: text('property_image'),
  userId: varchar('user_id', { length: 255 }).notNull(),
  userName: varchar('user_name', { length: 255 }),
  userEmail: varchar('user_email', { length: 255 }),
  userPhone: varchar('user_phone', { length: 20 }),
  date: timestamp('date').notNull(),
  time: varchar('time', { length: 10 }).notNull(),
  notes: text('notes'),
  status: varchar('status', { length: 20 }).default('pending'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow()
});

// Favorites Table
export const favorites = pgTable('favorites', {
  id: serial('id').primaryKey(),
  userId: varchar('user_id', { length: 255 }).notNull(),
  propertyId: integer('property_id').notNull(),
  createdAt: timestamp('created_at').defaultNow()
});

// Establish relations
export const usersRelations = relations(users, ({ many }) => ({
  properties: many(properties, { relationName: 'owner' }),
  bookings: many(bookings, { relationName: 'userBookings' }),
  favorites: many(favorites, { relationName: 'userFavorites' })
}));

export const propertiesRelations = relations(properties, ({ one, many }) => ({
  owner: one(users, {
    fields: [properties.ownerId],
    references: [users.uid],
    relationName: 'owner'
  }),
  bookings: many(bookings, { relationName: 'propertyBookings' }),
  favorited: many(favorites, { relationName: 'propertyFavorites' })
}));

export const bookingsRelations = relations(bookings, ({ one }) => ({
  property: one(properties, {
    fields: [bookings.propertyId],
    references: [properties.id],
    relationName: 'propertyBookings'
  }),
  user: one(users, {
    fields: [bookings.userId],
    references: [users.uid],
    relationName: 'userBookings'
  })
}));

export const favoritesRelations = relations(favorites, ({ one }) => ({
  user: one(users, {
    fields: [favorites.userId],
    references: [users.uid],
    relationName: 'userFavorites'
  }),
  property: one(properties, {
    fields: [favorites.propertyId],
    references: [properties.id],
    relationName: 'propertyFavorites'
  })
}));

// Types
export type User = InferModel<typeof users>;
export type InsertUser = InferModel<typeof users, 'insert'>;

export type Property = InferModel<typeof properties>;
export type InsertProperty = InferModel<typeof properties, 'insert'>;

export type Booking = InferModel<typeof bookings>;
export type InsertBooking = InferModel<typeof bookings, 'insert'>;

export type Favorite = InferModel<typeof favorites>;
export type InsertFavorite = InferModel<typeof favorites, 'insert'>;