#!/bin/bash

# Script to prepare Android project for building
# This script sets the correct permissions and performs other
# necessary tasks before opening in Android Studio

echo "Preparing Android project for building..."

# Create local.properties if it doesn't exist
if [ ! -f "android/local.properties" ]; then
  echo "Creating local.properties..."
  
  # Try to detect Android SDK location
  if [ -n "$ANDROID_HOME" ]; then
    SDK_DIR="$ANDROID_HOME"
  elif [ -n "$ANDROID_SDK_ROOT" ]; then
    SDK_DIR="$ANDROID_SDK_ROOT"
  elif [ -d "$HOME/Android/Sdk" ]; then
    SDK_DIR="$HOME/Android/Sdk"
  elif [ -d "$HOME/Library/Android/sdk" ]; then
    SDK_DIR="$HOME/Library/Android/sdk"
  else
    echo "Android SDK not found. Please edit local.properties manually."
    SDK_DIR="/path/to/your/Android/Sdk"
  fi
  
  echo "sdk.dir=$SDK_DIR" > android/local.properties
  echo "Created local.properties with sdk.dir=$SDK_DIR"
fi

# Set executable permissions for gradlew
if [ -f "android/gradlew" ]; then
  echo "Setting executable permissions for gradlew..."
  chmod +x android/gradlew
fi

# Create signing configuration (optional)
if [ ! -f "android/app/signing.properties" ]; then
  echo "Creating signing.properties template..."
  cat > android/app/signing.properties <<EOL
# Signing configuration for release builds
# Uncomment and modify these lines to enable release signing

#storeFile=/path/to/your/keystore.jks
#storePassword=your_keystore_password
#keyAlias=your_key_alias
#keyPassword=your_key_password
EOL
  echo "Created signing.properties template"
fi

# Check for google-services.json
if [ ! -f "android/app/google-services.json" ]; then
  echo "WARNING: google-services.json not found in android/app/"
  echo "If you're using Firebase, you need to add this file from your Firebase console"
fi

# Create a build script for easy APK building
echo "Creating build-apk.sh script..."
cat > android/build-apk.sh <<EOL
#!/bin/bash
# Script to build debug and release APKs

echo "Building GoExploree APKs..."

# Debug APK
./gradlew assembleDebug
echo "Debug APK created at: app/build/outputs/apk/debug/app-debug.apk"

# Release APK (requires signing configuration)
if grep -q "^storeFile" app/signing.properties; then
  ./gradlew assembleRelease
  echo "Release APK created at: app/build/outputs/apk/release/app-release.apk"
else
  echo "Skipping release build - signing configuration not set up"
  echo "Edit app/signing.properties to enable release builds"
fi
EOL
chmod +x android/build-apk.sh

echo "Android project preparation complete!"
echo "You can now open the project in Android Studio or run android/build-apk.sh"