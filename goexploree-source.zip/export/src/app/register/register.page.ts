import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { LoadingController, ToastController } from '@ionic/angular';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
  standalone: false
})
export class RegisterPage implements OnInit {
  registerForm: FormGroup;
  returnUrl: string;
  isLoading = false;
  
  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private loadingController: LoadingController,
    private toastController: ToastController
  ) {
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validator: this.passwordMatchValidator });
  }

  ngOnInit() {
    // Get return URL from route parameters or default to '/home'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
    
    // Redirect if already logged in
    this.authService.isAuthenticated$.subscribe(isAuthenticated => {
      if (isAuthenticated) {
        this.router.navigate([this.returnUrl]);
      }
    });
  }

  // Custom validator to check if passwords match
  passwordMatchValidator(g: FormGroup) {
    return g.get('password')?.value === g.get('confirmPassword')?.value
      ? null : { 'mismatch': true };
  }

  async register() {
    if (this.registerForm.invalid) {
      return;
    }

    this.isLoading = true;
    const loading = await this.loadingController.create({
      message: 'Creating your account...',
      spinner: 'bubbles',
    });
    await loading.present();

    const { email, password } = this.registerForm.value;

    this.authService.signUp(email, password)
      .then(result => {
        loading.dismiss();
        this.showSuccessToast('Account created successfully!');
        this.router.navigateByUrl(this.returnUrl);
      })
      .catch(error => {
        loading.dismiss();
        this.isLoading = false;
        this.showErrorToast(this.getErrorMessage(error.code));
      });
  }

  async registerWithGoogle() {
    this.isLoading = true;
    const loading = await this.loadingController.create({
      message: 'Creating your account with Google...',
      spinner: 'bubbles',
    });
    await loading.present();

    this.authService.signInWithGoogle()
      .then(result => {
        loading.dismiss();
        this.showSuccessToast('Account created successfully!');
        this.router.navigateByUrl(this.returnUrl);
      })
      .catch(error => {
        loading.dismiss();
        this.isLoading = false;
        this.showErrorToast('Failed to create account with Google. Please try again.');
      });
  }

  async showSuccessToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'bottom',
      color: 'success',
      buttons: [
        {
          text: 'OK',
          role: 'cancel'
        }
      ]
    });
    toast.present();
  }

  async showErrorToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'bottom',
      color: 'danger',
      buttons: [
        {
          text: 'OK',
          role: 'cancel'
        }
      ]
    });
    toast.present();
  }

  getErrorMessage(errorCode: string): string {
    switch (errorCode) {
      case 'auth/email-already-in-use':
        return 'The email address is already in use by another account.';
      case 'auth/invalid-email':
        return 'The email address is invalid.';
      case 'auth/operation-not-allowed':
        return 'Password sign-in is disabled for this project.';
      case 'auth/weak-password':
        return 'The password is too weak. Please use a stronger password.';
      default:
        return 'An error occurred during registration. Please try again.';
    }
  }

  goToLogin() {
    this.router.navigate(['/login'], { queryParams: { returnUrl: this.returnUrl } });
  }
}
