import { Injectable } from '@angular/core';
import { AngularFirestore, DocumentReference } from '@angular/fire/compat/firestore';
import { Observable, of, from, concat } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { PropertyModel } from '../models/property.model';
import { DatabaseService } from './database.service';
import { PropertyApiService } from './property-api.service';
import { StorageService } from './storage.service';

@Injectable({
  providedIn: 'root'
})
export class PropertyService {
  private readonly COLLECTION_NAME = 'properties';
  private countries = ['united states', 'canada', 'united kingdom', 'australia'];

  constructor(
    private firestore: AngularFirestore,
    private dbService: DatabaseService,
    private propertyApiService: PropertyApiService,
    private storageService: StorageService
  ) { }

  // Get all properties
  getAllProperties(): Observable<PropertyModel[]> {
    console.log('Fetching properties from Zylalabs API');
    
    // Get a random country from our list
    const randomCountry = this.countries[Math.floor(Math.random() * this.countries.length)];
    
    // Use the Zylalabs API to get real property data
    return this.propertyApiService.getPropertiesByCountry(randomCountry)
      .pipe(
        tap(properties => console.log(`Fetched ${properties.length} properties from Zylalabs API`)),
        catchError(error => {
          console.error('Error fetching properties from Zylalabs API, falling back to Firebase:', error);
          
          // Fallback to Firebase if the API fails
          console.log('Falling back to Firebase for properties');
          return this.firestore.collection<PropertyModel>(this.COLLECTION_NAME)
            .valueChanges({ idField: 'id' })
            .pipe(
              catchError(fbError => {
                console.error('Error fetching properties from Firebase:', fbError);
                return of([]);
              })
            );
        })
      );
  }

  // Track search results and featured properties for property details view
  private searchResultsCache: PropertyModel[] = [];
  private featuredPropertiesCache: PropertyModel[] = [];

  // Cache search results for property details access
  cacheSearchResults(properties: PropertyModel[]) {
    console.log('Caching search results:', properties.length);
    this.searchResultsCache = properties;
  }
  
  // Cache featured properties separately
  cacheFeaturedProperties(properties: PropertyModel[]) {
    console.log('Caching featured properties:', properties.length);
    this.featuredPropertiesCache = properties;
  }
  
  // Get the current cached properties
  getCachedProperties(): PropertyModel[] {
    return this.searchResultsCache;
  }

  // Get property by ID - handles both Firebase and search-generated properties
  getPropertyById(id: string | number): Observable<PropertyModel | null> {
    console.log(`Getting property with ID: ${id}, type: ${typeof id}`);
    
    // Log the current state of caches for debugging
    console.log(`Current search cache has ${this.searchResultsCache.length} properties`);
    console.log(`Current featured cache has ${this.featuredPropertiesCache.length} properties`);
    
    // First, try to find property by string ID in the caches
    const stringId = id.toString();
    
    // Try direct string comparison in caches first
    console.log('Checking for exact string match in caches with ID:', stringId);
    const cachedByString = this.searchResultsCache.find(p => p.id.toString() === stringId);
    if (cachedByString) {
      console.log('Found property in search cache by string match:', cachedByString.title);
      return of(cachedByString);
    }
    
    const featuredByString = this.featuredPropertiesCache.find(p => p.id.toString() === stringId);
    if (featuredByString) {
      console.log('Found property in featured cache by string match:', featuredByString.title);
      return of(featuredByString);
    }
    
    // Try to parse as a number for numeric ID comparison
    const numericId = typeof id === 'string' ? parseInt(id) : id;
    
    // Handle any numeric IDs
    if (!isNaN(numericId)) {
      console.log('Looking for property in search cache with numeric ID:', numericId);
      
      // Check our search results cache with numeric comparison
      const cachedProperty = this.searchResultsCache.find(p => {
        const propId = typeof p.id === 'string' ? parseInt(p.id) : p.id;
        return propId === numericId;
      });
      
      if (cachedProperty) {
        console.log('Found property in search cache by numeric match:', cachedProperty.title);
        return of(cachedProperty);
      }
      
      // Also check the featured properties cache with numeric comparison
      const featuredProperty = this.featuredPropertiesCache.find(p => {
        const propId = typeof p.id === 'string' ? parseInt(p.id) : p.id;
        return propId === numericId;
      });
      
      if (featuredProperty) {
        console.log('Found property in featured properties cache by numeric match:', featuredProperty.title);
        return of(featuredProperty);
      }
    }
    
    // If no match in cache or not a search-generated ID, try Firebase
    console.log('Looking for property in Firebase with ID:', id);
    return this.firestore.doc<PropertyModel>(`${this.COLLECTION_NAME}/${id}`)
      .valueChanges({ idField: 'id' })
      .pipe(
        catchError(error => {
          console.error(`Error fetching property with ID ${id} from Firebase:`, error);
          return of(null);
        })
      );
  }

  // Add a new property with image upload
  async addProperty(property: Omit<PropertyModel, 'id'>): Promise<DocumentReference<unknown>> {
    console.log('Starting property addition with image upload...');
    
    try {
      // Check if the image is a base64 string that needs to be uploaded
      if (property.imageUrl && property.imageUrl.startsWith('data:image')) {
        console.log('Image is base64, uploading to Firebase Storage...');
        // Upload the image to Firebase Storage first
        const imageUrl = await this.storageService.uploadImage(property.imageUrl);
        console.log('Image uploaded successfully:', imageUrl);
        
        // Replace the base64 image with the Storage URL
        property = {
          ...property,
          imageUrl: imageUrl
        };
      }
      
      // Now add the property to Firestore with the image URL
      console.log('Adding property to Firestore with image URL...');
      return this.firestore.collection(this.COLLECTION_NAME).add({
        ...property,
        createdAt: new Date()
      });
    } catch (error) {
      console.error('Error in addProperty:', error);
      throw error;
    }
  }

  // Update a property with image handling
  async updateProperty(id: string, property: Partial<PropertyModel>): Promise<void> {
    console.log('Starting property update...');
    
    try {
      // Check if there's a new image to upload (base64 string)
      if (property.imageUrl && property.imageUrl.startsWith('data:image')) {
        console.log('New image detected, uploading to Firebase Storage...');
        
        // Get the current property to check if there's an existing image to delete
        const currentProperty = await this.firestore.doc<PropertyModel>(`${this.COLLECTION_NAME}/${id}`)
          .get().toPromise();
        
        // Upload the new image
        const imageUrl = await this.storageService.uploadImage(property.imageUrl);
        console.log('New image uploaded successfully:', imageUrl);
        
        // If there was an existing image URL from Storage, delete it
        const existingImageUrl = currentProperty?.data()?.imageUrl;
        if (existingImageUrl && existingImageUrl.includes('firebase') && !existingImageUrl.startsWith('data:')) {
          try {
            await this.storageService.deleteImage(existingImageUrl);
            console.log('Old image deleted successfully');
          } catch (deleteError) {
            console.error('Error deleting old image:', deleteError);
            // Continue with the update even if deletion fails
          }
        }
        
        // Replace the base64 image with the Storage URL
        property = {
          ...property,
          imageUrl: imageUrl
        };
      }
      
      // Update the property in Firestore
      console.log('Updating property in Firestore...');
      return await this.firestore.doc(`${this.COLLECTION_NAME}/${id}`).update({
        ...property,
        updatedAt: new Date()
      });
    } catch (error) {
      console.error('Error in updateProperty:', error);
      throw error;
    }
  }

  // Delete a property and its image
  async deleteProperty(id: string): Promise<void> {
    console.log('Starting property deletion...');
    
    try {
      // First get the property to check if there's an image to delete
      const propertyDoc = await this.firestore.doc<PropertyModel>(`${this.COLLECTION_NAME}/${id}`)
        .get().toPromise();
      
      const property = propertyDoc?.data();
      
      // If there's an image URL from Firebase Storage, delete it
      if (property?.imageUrl && property.imageUrl.includes('firebase') && !property.imageUrl.startsWith('data:')) {
        try {
          console.log('Deleting property image from storage...');
          await this.storageService.deleteImage(property.imageUrl);
          console.log('Property image deleted successfully');
        } catch (deleteError) {
          console.error('Error deleting property image:', deleteError);
          // Continue with the property deletion even if image deletion fails
        }
      }
      
      // Now delete the property from Firestore
      console.log('Deleting property from Firestore...');
      return await this.firestore.doc(`${this.COLLECTION_NAME}/${id}`).delete();
    } catch (error) {
      console.error('Error in deleteProperty:', error);
      throw error;
    }
  }

  // Get properties by user ID
  getPropertiesByUserId(userId: string): Observable<PropertyModel[]> {
    return this.firestore.collection<PropertyModel>(this.COLLECTION_NAME, 
      ref => ref.where('ownerId', '==', userId))
      .valueChanges({ idField: 'id' })
      .pipe(
        catchError(error => {
          console.error(`Error fetching properties for user ${userId}:`, error);
          return of([]);
        })
      );
  }

  // Search properties by title, description, or location
  searchProperties(searchTerm: string): Observable<PropertyModel[]> {
    console.log(`Searching properties with term: ${searchTerm}`);
    
    // If empty search, restore all properties
    if (!searchTerm.trim()) {
      return this.getAllProperties();
    }
    
    // For location-based searches (cities, countries)
    const isLocationSearch = /^[a-zA-Z0-9,\s]+$/.test(searchTerm) && 
                            !searchTerm.includes('bedroom') && 
                            !searchTerm.includes('bath');
    
    if (isLocationSearch) {
      console.log('Search term looks like a location, using location-based search');
      return this.propertyApiService.searchPropertiesByLocation(searchTerm);
    }
    
    // For feature-based or descriptive searches
    console.log('Using text-based search on existing properties');
    return this.getAllProperties().pipe(
      map(properties => 
        properties.filter(property => 
          property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          property.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          property.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
          // Also search in features
          property.features.some(feature => 
            feature.toLowerCase().includes(searchTerm.toLowerCase())
          ) ||
          // Search for bedroom/bathroom count
          (searchTerm.includes('bedroom') && 
           property.bedrooms.toString() === searchTerm.replace(/\D/g, '')) ||
          (searchTerm.includes('bath') && 
           property.bathrooms.toString() === searchTerm.replace(/\D/g, ''))
        )
      )
    );
  }

  // Get featured properties (first 5 properties)
  getFeaturedProperties(): Observable<PropertyModel[]> {
    console.log('Fetching featured properties from Zylalabs API');
    
    // Get a different random country for featured properties
    const featuredCountryIndex = Math.floor(Math.random() * this.countries.length);
    const featuredCountry = this.countries[featuredCountryIndex];
    
    // Use the Zylalabs API to get featured properties
    return this.propertyApiService.getPropertiesByCountry(featuredCountry)
      .pipe(
        map(properties => {
          console.log(`Fetched ${properties.length} featured properties from Zylalabs API`);
          // Take the first 5 or fewer properties
          const featured = properties.slice(0, 5);
          // Cache the featured properties
          this.featuredPropertiesCache = featured;
          return featured;
        }),
        catchError(error => {
          console.error('Error fetching featured properties from Zylalabs API, falling back to Firebase:', error);
          
          // Fallback to Firebase if the API fails
          console.log('Falling back to Firebase for featured properties');
          return this.firestore.collection<PropertyModel>(this.COLLECTION_NAME, 
            ref => ref.orderBy('createdAt', 'desc').limit(5))
            .valueChanges({ idField: 'id' })
            .pipe(
              map(fbProperties => {
                // Cache the featured properties from Firebase
                this.featuredPropertiesCache = fbProperties;
                return fbProperties;
              }),
              catchError(fbError => {
                console.error('Error fetching featured properties from Firebase:', fbError);
                return of([]);
              })
            );
        })
      );
  }
}
