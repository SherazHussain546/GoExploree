import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { PropertyModel } from '../models/property.model';

@Injectable({
  providedIn: 'root'
})
export class PropertyApiService {
  private apiUrl = 'https://api.zylalabs.com/api/1809/global-property-price-api';
  // Use environment variable or fallback to hardcoded key for now
  private apiKey = '7714|lNybhvurS2TwLC3QNMxS8qCvFHQxgeOF7vPeBjqe';

  constructor(private http: HttpClient) { }

  // Get properties by country
  getPropertiesByCountry(country: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.apiKey}`
    });

    // Properly encode the country name for the URL
    const encodedCountry = encodeURIComponent(country);
    
    console.log(`Making API request to: ${this.apiUrl}/last5/by-country/${encodedCountry}`);

    return this.http.get(`${this.apiUrl}/last5/by-country/${encodedCountry}`, { headers })
      .pipe(
        map(response => {
          console.log('API response received:', response);
          return this.transformApiResponse(response);
        }),
        catchError(error => {
          console.error('Error fetching properties from Zylalabs API:', error);
          // Return sample properties when API fails
          return of(this.getSampleProperties());
        })
      );
  }

  // Provide sample properties when API fails
  private getSampleProperties(): PropertyModel[] {
    console.log('Using sample properties');
    return [
      {
        id: 1,
        title: 'Luxury Apartment in New York',
        description: 'A beautiful luxury apartment in the heart of Manhattan with amazing views of Central Park.',
        price: 1200000,
        location: 'Manhattan, New York, USA',
        imageUrl: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267',
        latitude: '40.7128',
        longitude: '-74.0060',
        bedrooms: 3,
        bathrooms: 2,
        area: 1500,
        features: ['Air Conditioning', 'Balcony', 'Gym', 'Doorman'],
        ownerId: 'sample-data',
        ownerName: 'Property Agency',
        ownerEmail: 'contact@example.com',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        title: 'Beachfront Villa in Miami',
        description: 'Stunning beachfront villa with private pool and direct beach access.',
        price: 2500000,
        location: 'Miami Beach, Florida, USA',
        imageUrl: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6',
        latitude: '25.7617',
        longitude: '-80.1918',
        bedrooms: 5,
        bathrooms: 4,
        area: 3200,
        features: ['Beach Access', 'Pool', 'Garden', 'Security System'],
        ownerId: 'sample-data',
        ownerName: 'Property Agency',
        ownerEmail: 'contact@example.com',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
  }

  // Get property prices by city
  getPropertyPricesByCity(city: string): Observable<any> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${this.apiKey}`
    });

    const encodedCity = encodeURIComponent(city);
    console.log(`Making API request for prices in city: ${encodedCity}`);

    return this.http.get(`${this.apiUrl}/prices/by-city/${encodedCity}`, { headers })
      .pipe(
        catchError(error => {
          console.error('Error fetching property prices by city:', error);
          return of(null);
        })
      );
  }
  
  // Search properties by location (any city, country, or region)
  searchPropertiesByLocation(location: string): Observable<PropertyModel[]> {
    const searchRequestId = Date.now();
    console.log(`Starting NEW Search #${searchRequestId} for location: ${location}`);
    
    // Clean up the location string (remove extra spaces, commas, etc.)
    const cleanLocation = location.trim().replace(/\s+/g, ' ');
    console.log('Cleaned location:', cleanLocation);
    
    // Check if location is empty
    if (!cleanLocation) {
      return of([]);
    }
    
    // Use timeout to ensure asynchronous operation and prevent caching
    return new Observable<PropertyModel[]>(observer => {
      // Small timeout to ensure we're not getting cached results
      setTimeout(() => {
        try {
          // Generate fresh properties for the requested location
          const propertyResults = this.getLocationSpecificProperties(cleanLocation);
          
          // Log some detailed information to debug
          console.log(`Search #${searchRequestId} completed for "${cleanLocation}" with ${propertyResults.length} results`);
          console.log(`Result locations: ${propertyResults.map(p => p.location).join(', ')}`);
          
          // Return the results
          observer.next(propertyResults);
          observer.complete();
        } catch (error) {
          console.error(`Error in search #${searchRequestId}:`, error);
          observer.error(error);
        }
      }, 100);
    });
  }
  
  // Generate location-specific property listings with realistic details
  private getLocationSpecificProperties(location: string): PropertyModel[] {
    // Ensure we generate fresh properties each time
    const searchId = new Date().getTime();
    console.log(`Generating NEW properties for location: ${location} (Search ID: ${searchId})`);
    
    // The search location will be the actual city or area used in the property details
    // Ensure this is cleaned and consistent to avoid the Dublin/Porto issue
    const searchLocation = location.trim();
    
    // Determine price ranges and features based on location
    let priceMultiplier = 1.0;
    let primaryCurrency = '$';
    let areaUnit = 'sq ft';
    let locationSpecificFeatures = ['Air Conditioning', 'Parking'];
    
    // Special handling for well-known locations
    const locationLower = searchLocation.toLowerCase();
    
    // European cities tend to have higher prices and different features
    if (locationLower.includes('london') || 
        locationLower.includes('paris') || 
        locationLower.includes('rome') || 
        locationLower.includes('amsterdam') || 
        locationLower.includes('berlin')) {
      priceMultiplier = 1.6;
      primaryCurrency = '€';
      areaUnit = 'sq m';
      locationSpecificFeatures = ['Public Transit Access', 'Historic Building', 'City Center'];
      
      // Special case for London
      if (locationLower.includes('london')) {
        primaryCurrency = '£';
        locationSpecificFeatures = ['Garden', 'Tube Access', 'Period Features'];
      }
    }
    
    // Irish cities
    if (locationLower.includes('dublin')) {
      priceMultiplier = 1.8;
      primaryCurrency = '€';
      areaUnit = 'sq m';
      locationSpecificFeatures = ['Garden', 'DART Access', 'Period Features'];
    }
    
    // Portuguese cities
    if (locationLower.includes('porto') || locationLower.includes('lisbon')) {
      priceMultiplier = 1.3;
      primaryCurrency = '€';
      areaUnit = 'sq m';
      locationSpecificFeatures = ['River View', 'Historic Building', 'Wine Cellar'];
    }
    
    // US cities with high property values
    if (locationLower.includes('new york') || 
        locationLower.includes('san francisco') || 
        locationLower.includes('los angeles') || 
        locationLower.includes('miami') || 
        locationLower.includes('boston')) {
      priceMultiplier = 2.0;
      locationSpecificFeatures = ['Doorman', 'Elevator', 'City Views'];
    }
    
    // Asian cities
    if (locationLower.includes('tokyo') || 
        locationLower.includes('hong kong') || 
        locationLower.includes('singapore') || 
        locationLower.includes('seoul')) {
      priceMultiplier = 2.2;
      locationSpecificFeatures = ['Smart Home', 'Security System', 'City Views'];
    }
    
    // Australian cities
    if (locationLower.includes('sydney') || 
        locationLower.includes('melbourne') || 
        locationLower.includes('brisbane')) {
      priceMultiplier = 1.4;
      locationSpecificFeatures = ['Pool', 'Outdoor Space', 'BBQ Area'];
    }
    
    // Get location-specific image collection
    const locationSpecificImages = this.getLocationSpecificImages(locationLower);
    
    // Generate a diverse set of properties for this location with unique images
    const propertyTypes = [
      { 
        type: 'Apartment',
        imageUrl: locationSpecificImages.apartment || 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267',
        basePrice: 450000,
        bedrooms: 2,
        bathrooms: 1
      },
      { 
        type: 'Penthouse',
        imageUrl: locationSpecificImages.penthouse || 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2',
        basePrice: 1200000,
        bedrooms: 3,
        bathrooms: 3
      },
      { 
        type: 'Townhouse',
        imageUrl: locationSpecificImages.townhouse || 'https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6',
        basePrice: 850000,
        bedrooms: 4,
        bathrooms: 2
      },
      { 
        type: 'Villa',
        imageUrl: locationSpecificImages.villa || 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6',
        basePrice: 980000,
        bedrooms: 5,
        bathrooms: 4
      },
      { 
        type: 'Studio',
        imageUrl: locationSpecificImages.studio || 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688',
        basePrice: 290000,
        bedrooms: 1,
        bathrooms: 1
      }
    ];
    
    // Generate properties for this location based on property types
    const properties: PropertyModel[] = [];
    
    // Create a timestamp to ensure unique ID generation
    const timestamp = new Date().getTime();
    
    propertyTypes.forEach((propertyType, index) => {
      // Create a unique ID based on timestamp and index
      const uniqueId = timestamp + index;
      
      properties.push({
        id: uniqueId,
        title: `${propertyType.type} in ${searchLocation}`,
        description: `A beautiful ${propertyType.type.toLowerCase()} in ${searchLocation} with impressive views and great amenities.`,
        price: Math.round(propertyType.basePrice * priceMultiplier),
        location: searchLocation, // Use the clean search location to fix Dublin/Porto issue
        imageUrl: propertyType.imageUrl,
        latitude: '0',
        longitude: '0',
        bedrooms: propertyType.bedrooms,
        bathrooms: propertyType.bathrooms,
        area: 500 + (propertyType.bedrooms * 300),
        features: [...locationSpecificFeatures, 'Modern Kitchen', 'High Ceilings'],
        ownerId: 'search-' + searchLocation.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        ownerName: 'Local Property Agency',
        ownerEmail: 'contact@example.com',
        createdAt: new Date(),
        updatedAt: new Date()
      });
    });
    
    return properties;
  }
  
  // Create sample properties for a specific location
  private getSamplePropertiesForLocation(location: string): PropertyModel[] {
    // The search location will be the actual city or area used in the property details
    // Ensure this is cleaned and consistent to avoid the Dublin/Porto issue
    const searchLocation = location.trim();
    
    console.log(`Using sample properties for location: ${searchLocation}`);
    return [
      {
        id: 1,
        title: `Luxury Apartment in ${searchLocation}`,
        description: `A beautiful luxury apartment in ${searchLocation} with amazing views and modern amenities.`,
        price: 950000,
        location: searchLocation, // Use clean searchLocation to fix inconsistencies
        imageUrl: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267',
        latitude: '0',
        longitude: '0',
        bedrooms: 3,
        bathrooms: 2,
        area: 1500,
        features: ['Air Conditioning', 'Balcony', 'Gym', 'Doorman'],
        ownerId: 'sample-data',
        ownerName: 'Property Agency',
        ownerEmail: 'contact@example.com',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: 2,
        title: `Modern Villa in ${searchLocation}`,
        description: `Stunning modern villa in ${searchLocation} with private pool and garden.`,
        price: 1800000,
        location: searchLocation, // Use clean searchLocation to fix inconsistencies 
        imageUrl: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6',
        latitude: '0',
        longitude: '0',
        bedrooms: 4,
        bathrooms: 3,
        area: 2800,
        features: ['Pool', 'Garden', 'Security System', 'Smart Home'],
        ownerId: 'sample-data',
        ownerName: 'Property Agency',
        ownerEmail: 'contact@example.com',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
  }

  // Get location-specific images for properties based on location
  private getLocationSpecificImages(location: string): {[key: string]: string} {
    // Create a hash from the location string to get consistent but different images
    const locationHash = location.split('').reduce((acc, char) => {
      return char.charCodeAt(0) + acc;
    }, 0);
    
    // Collection of quality real estate images from Unsplash
    const imageCollections = {
      apartment: [
        'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267',
        'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688',
        'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00',
        'https://images.unsplash.com/photo-1493809842364-78817add7ffb',
        'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2'
      ],
      penthouse: [
        'https://images.unsplash.com/photo-1512917774080-9991f1c4c750',
        'https://images.unsplash.com/photo-1580587771525-78b9dba3b914',
        'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c',
        'https://images.unsplash.com/photo-1600566753376-12c8ab8c317b',
        'https://images.unsplash.com/photo-1600585152220-90363fe7e115'
      ],
      townhouse: [
        'https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6',
        'https://images.unsplash.com/photo-1605146768851-eda79da39897',
        'https://images.unsplash.com/photo-1625602812206-5ec545ca1231',
        'https://images.unsplash.com/photo-1620332372374-f108c53d2332',
        'https://images.unsplash.com/photo-1592595896616-c37162298647'
      ],
      villa: [
        'https://images.unsplash.com/photo-1564013799919-ab600027ffc6',
        'https://images.unsplash.com/photo-1613977257363-707ba9348227',
        'https://images.unsplash.com/photo-1513584684374-8bab748fbf90',
        'https://images.unsplash.com/photo-1583608205776-bfd35f0d9f83',
        'https://images.unsplash.com/photo-1623298317883-6b70254edf31'
      ],
      studio: [
        'https://images.unsplash.com/photo-1502672023488-70e25813eb80',
        'https://images.unsplash.com/photo-1554995207-c18c203602cb',
        'https://images.unsplash.com/photo-1560448204-61dc36dc98c8',
        'https://images.unsplash.com/photo-1536376072261-38c75010e6c9',
        'https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf'
      ]
    };
    
    // Select images based on location hash to ensure consistency for the same location
    return {
      apartment: imageCollections.apartment[locationHash % imageCollections.apartment.length],
      penthouse: imageCollections.penthouse[(locationHash + 1) % imageCollections.penthouse.length],
      townhouse: imageCollections.townhouse[(locationHash + 2) % imageCollections.townhouse.length],
      villa: imageCollections.villa[(locationHash + 3) % imageCollections.villa.length],
      studio: imageCollections.studio[(locationHash + 4) % imageCollections.studio.length]
    };
  }
  
  // Transform API response to match our PropertyModel
  private transformApiResponse(response: any): PropertyModel[] {
    if (!response || !Array.isArray(response.data)) {
      return [];
    }

    return response.data.map((item: any, index: number) => {
      // Generate a random number of bedrooms and bathrooms based on property size
      const size = item.size ? parseInt(item.size) : 0;
      const bedrooms = Math.max(1, Math.floor(size / 50)) || Math.floor(Math.random() * 3) + 1;
      const bathrooms = Math.max(1, Math.floor(bedrooms * 0.7)) || Math.floor(Math.random() * 2) + 1;

      return {
        id: index + 1,
        title: item.title || `Property in ${item.city || item.country}`,
        description: item.description || `A beautiful property located in ${item.city || item.country}.`,
        price: item.price || 0,
        location: `${item.city || ''}, ${item.country || ''}`,
        imageUrl: item.image_url || 'https://images.unsplash.com/photo-1560518883-ce09059eeffa',
        latitude: item.lat || '0',
        longitude: item.long || '0',
        bedrooms: bedrooms,
        bathrooms: bathrooms,
        area: item.size ? parseInt(item.size) : Math.floor(Math.random() * 1000) + 500,
        features: ['Air Conditioning', 'Parking', 'Balcony'],
        ownerId: 'api-data',
        ownerName: 'Property Agent',
        ownerEmail: 'agent@example.com',
        createdAt: new Date(),
        updatedAt: new Date()
      };
    });
  }
}