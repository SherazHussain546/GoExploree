import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EnvService {
  // Firebase Configuration
  private _firebaseApiKey = '';
  private _firebaseProjectId = '';
  private _firebaseAppId = '';

  constructor() {
    // Get environment variables
    this._firebaseApiKey = (window as any)?.env?.VITE_FIREBASE_API_KEY || '';
    this._firebaseProjectId = (window as any)?.env?.VITE_FIREBASE_PROJECT_ID || '';
    this._firebaseAppId = (window as any)?.env?.VITE_FIREBASE_APP_ID || '';
  }

  get firebaseConfig() {
    return {
      apiKey: this._firebaseApiKey,
      projectId: this._firebaseProjectId,
      appId: this._firebaseAppId,
      authDomain: `${this._firebaseProjectId}.firebaseapp.com`,
      storageBucket: `${this._firebaseProjectId}.appspot.com`,
      messagingSenderId: '',
      measurementId: ''
    };
  }
}