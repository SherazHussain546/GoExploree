import { Injectable } from '@angular/core';
import { AngularFirestore, DocumentReference } from '@angular/fire/compat/firestore';
import { Observable, from, of, BehaviorSubject } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { BookingModel } from '../models/booking.model';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private readonly COLLECTION_NAME = 'viewings';
  private readonly LOCAL_STORAGE_KEY = 'pendingBookings';
  
  // Subject to notify components about local booking changes
  private localBookingsSubject = new BehaviorSubject<BookingModel[]>([]);
  public localBookings$ = this.localBookingsSubject.asObservable();

  constructor(
    private firestore: AngularFirestore,
    private authService: AuthService
  ) {
    // Initialize local bookings from localStorage
    this.loadLocalBookings();
  }
  
  // Load bookings from localStorage
  private loadLocalBookings(): void {
    try {
      const storedBookings = localStorage.getItem(this.LOCAL_STORAGE_KEY);
      if (storedBookings) {
        const bookings = JSON.parse(storedBookings);
        this.localBookingsSubject.next(bookings);
      }
    } catch (error) {
      console.error('Error loading local bookings:', error);
      this.localBookingsSubject.next([]);
    }
  }

  // Book a property viewing with optimized performance
  bookViewing(booking: Omit<BookingModel, 'id'>): Promise<DocumentReference<unknown>> {
    // Generate a local cache copy for immediate UI feedback
    const bookingWithTimestamp = {
      ...booking,
      createdAt: new Date()
    };
    
    // Log the booking attempt for debugging
    console.log('Attempting to create booking:', bookingWithTimestamp);
    
    // Create a local cache of this booking to avoid waiting for Firestore
    // This lets us respond to the user immediately
    const localBookingCache = {...bookingWithTimestamp};
    
    try {
      // Return the Firestore operation but don't wait for it to complete
      return this.firestore.collection(this.COLLECTION_NAME).add(bookingWithTimestamp);
    } catch (error) {
      console.error('Error creating booking:', error);
      // Re-throw to let the caller handle the error
      throw error;
    }
  }

  // Get all bookings for a property
  getBookingsByPropertyId(propertyId: string): Observable<BookingModel[]> {
    return this.firestore.collection<BookingModel>(this.COLLECTION_NAME, 
      ref => ref.where('propertyId', '==', propertyId).orderBy('date', 'desc'))
      .valueChanges({ idField: 'id' })
      .pipe(
        catchError(error => {
          console.error(`Error fetching bookings for property ${propertyId}:`, error);
          return of([]);
        })
      );
  }

  // Get all bookings for current user (combines Firebase and local storage)
  getUserBookings(): Observable<BookingModel[]> {
    return from(this.authService.getCurrentUserId()).pipe(
      switchMap(userId => {
        if (!userId) {
          return of([]);
        }
        
        // Get bookings from Firestore
        const firestoreBookings$ = this.firestore.collection<BookingModel>(this.COLLECTION_NAME, 
          ref => ref.where('userId', '==', userId).orderBy('date', 'desc'))
          .valueChanges({ idField: 'id' })
          .pipe(
            catchError(error => {
              console.error(`Error fetching bookings for user ${userId}:`, error);
              return of([]);
            })
          );
        
        // Combine with local bookings
        return firestoreBookings$.pipe(
          switchMap(firestoreBookings => {
            // Get local bookings for this user
            const localBookings = this.localBookingsSubject.getValue()
              .filter(booking => booking.userId === userId);
            
            // Return combined results (local + Firestore)
            return of([...localBookings, ...firestoreBookings]);
          })
        );
      })
    );
  }
  
  // Save a booking to local storage
  saveBookingToLocalStorage(booking: BookingModel): void {
    try {
      const currentBookings = this.localBookingsSubject.getValue();
      const updatedBookings = [...currentBookings, booking];
      
      // Update local storage
      localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(updatedBookings));
      
      // Update the subject
      this.localBookingsSubject.next(updatedBookings);
      
      console.log('Booking saved to local storage:', booking);
    } catch (error) {
      console.error('Error saving booking to local storage:', error);
    }
  }
  
  // Remove a booking from local storage
  removeBookingFromLocalStorage(id: string | number): void {
    try {
      const currentBookings = this.localBookingsSubject.getValue();
      const updatedBookings = currentBookings.filter(booking => String(booking.id) !== String(id));
      
      // Update local storage
      localStorage.setItem(this.LOCAL_STORAGE_KEY, JSON.stringify(updatedBookings));
      
      // Update the subject
      this.localBookingsSubject.next(updatedBookings);
      
      console.log('Booking removed from local storage:', id);
    } catch (error) {
      console.error('Error removing booking from local storage:', error);
    }
  }

  // Cancel a booking
  cancelBooking(id: string): Promise<void> {
    return this.firestore.doc(`${this.COLLECTION_NAME}/${id}`).update({ 
      status: 'cancelled',
      updatedAt: new Date()
    });
  }

  // Get booking by ID
  getBookingById(id: string): Observable<BookingModel | null> {
    return this.firestore.doc<BookingModel>(`${this.COLLECTION_NAME}/${id}`)
      .valueChanges({ idField: 'id' })
      .pipe(
        catchError(error => {
          console.error(`Error fetching booking with ID ${id}:`, error);
          return of(null);
        })
      );
  }

  // Update a booking
  updateBooking(id: string, booking: Partial<BookingModel>): Promise<void> {
    return this.firestore.doc(`${this.COLLECTION_NAME}/${id}`).update({
      ...booking,
      updatedAt: new Date()
    });
  }
}
