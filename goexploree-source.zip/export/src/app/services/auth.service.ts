import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserModel } from '../models/user.model';
import firebase from 'firebase/compat/app';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUser = new BehaviorSubject<firebase.User | null>(null);
  private isAuthenticated = new BehaviorSubject<boolean>(false);

  currentUser$ = this.currentUser.asObservable();
  isAuthenticated$ = this.isAuthenticated.asObservable();

  constructor(private afAuth: AngularFireAuth) {
    // Initialize auth state
    this.afAuth.authState.subscribe(user => {
      this.currentUser.next(user);
      this.isAuthenticated.next(!!user);
    });
  }

  // Sign in with email/password
  signIn(email: string, password: string): Promise<any> {
    return this.afAuth.signInWithEmailAndPassword(email, password);
  }

  // Sign up with email/password
  signUp(email: string, password: string): Promise<any> {
    return this.afAuth.createUserWithEmailAndPassword(email, password);
  }

  // Sign in with Google
  signInWithGoogle(): Promise<any> {
    const provider = new firebase.auth.GoogleAuthProvider();
    // Add scopes for Google
    provider.addScope('profile');
    provider.addScope('email');
    // Set custom parameters for Google
    provider.setCustomParameters({
      prompt: 'select_account'
    });
    
    console.log('Attempting Google sign-in with Firebase config:', {
      apiKey: (window as any).env?.VITE_FIREBASE_API_KEY,
      projectId: (window as any).env?.VITE_FIREBASE_PROJECT_ID,
      appId: (window as any).env?.VITE_FIREBASE_APP_ID
    });
    
    return this.afAuth.signInWithPopup(provider)
      .then(result => {
        console.log('Google sign-in successful', result.user);
        return result;
      })
      .catch(error => {
        console.error('Google sign-in error:', error);
        throw error;
      });
  }

  // Sign out - clear cache when signing out
  signOut(): Promise<void> {
    // Clear ID cache
    this.userIdCache = { id: null, timestamp: 0 };
    return this.afAuth.signOut();
  }

  // Cache to avoid repeated expensive async calls
  private userIdCache: { id: string | null, timestamp: number } = { id: null, timestamp: 0 };
  
  // Get current user ID - optimized with cache
  async getCurrentUserId(): Promise<string | null> {
    // First check if we already have an authenticated user in memory
    const cachedUser = this.currentUser.getValue();
    if (cachedUser) {
      return cachedUser.uid;
    }
    
    // Check if we have a recent cache (valid for 5 minutes)
    const now = Date.now();
    if (this.userIdCache.id && (now - this.userIdCache.timestamp < 300000)) {
      return this.userIdCache.id;
    }
    
    // If not, try to get from Firebase with a timeout
    try {
      // Create a promise that resolves after 500ms to prevent UI freezing
      const timeoutPromise = new Promise<null>((resolve) => {
        setTimeout(() => {
          console.log('getCurrentUserId timed out');
          resolve(null);
        }, 500);
      });
      
      // Race the Firebase call with our timeout
      const userPromise = this.afAuth.currentUser;
      const user = await Promise.race([userPromise, timeoutPromise]);
      
      // Update cache if we got a user
      if (user) {
        this.userIdCache = { id: user.uid, timestamp: now };
        return user.uid;
      }
      return null;
    } catch (error) {
      console.error('Error getting current user ID:', error);
      return null;
    }
  }

  // Get current user email
  getCurrentUserEmail(): string | null {
    const user = this.currentUser.getValue();
    return user ? user.email : null;
  }

  // Check if user is authenticated
  isUserAuthenticated(): boolean {
    return !!this.currentUser.getValue();
  }

  // Convert Firebase User to UserModel
  getUserData(): UserModel | null {
    const user = this.currentUser.getValue();
    if (!user) return null;

    return {
      uid: user.uid,
      email: user.email || '',
      displayName: user.displayName || '',
      photoURL: user.photoURL || '',
    };
  }
  
  // Check auth state (used when app is resumed from background)
  async checkAuthState(): Promise<void> {
    try {
      // Force refresh the auth state by directly querying Firebase
      const user = await this.afAuth.currentUser;
      
      // Update our local state
      this.currentUser.next(user);
      this.isAuthenticated.next(!!user);
      
      // Clear ID cache if user is null (logged out)
      if (!user) {
        this.userIdCache = { id: null, timestamp: 0 };
      } else {
        // Update cache with current user
        this.userIdCache = { id: user.uid, timestamp: Date.now() };
      }
      
      console.log('Auth state refreshed:', !!user);
    } catch (error) {
      console.error('Error checking auth state:', error);
    }
  }
}
