import { Injectable } from '@angular/core';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  
  constructor(private storage: AngularFireStorage) { }
  
  /**
   * Upload an image file to Firebase Storage
   * @param file The file to upload
   * @param path The storage path (defaults to 'property-images')
   * @returns A Promise with the download URL
   */
  uploadImage(imageData: string, path: string = 'property-images'): Promise<string> {
    return new Promise(async (resolve, reject) => {
      try {
        // Create a unique filename
        const filename = `${new Date().getTime()}_${Math.random().toString(36).substring(2, 15)}`;
        const fullPath = `${path}/${filename}`;
        
        // Convert base64 string to blob
        const blob = this.dataURItoBlob(imageData);
        
        // Create a reference to the storage location
        const fileRef = this.storage.ref(fullPath);
        
        // Upload the file
        const task = this.storage.upload(fullPath, blob);
        
        // Monitor the upload progress
        task.percentageChanges().subscribe(
          percentage => {
            console.log(`Upload progress: ${percentage}%`);
          },
          error => {
            console.error('Upload error:', error);
            reject(error);
          }
        );
        
        // Get the download URL once upload completes
        task.snapshotChanges().pipe(
          finalize(() => {
            fileRef.getDownloadURL().subscribe(
              downloadURL => {
                console.log('File available at', downloadURL);
                resolve(downloadURL);
              },
              error => {
                console.error('Error getting download URL:', error);
                reject(error);
              }
            );
          })
        ).subscribe();
        
      } catch (error) {
        console.error('Error in upload process:', error);
        reject(error);
      }
    });
  }
  
  /**
   * Convert a base64 data URI to a Blob
   */
  private dataURItoBlob(dataURI: string): Blob {
    // Convert base64/URLEncoded data component to raw binary data
    let byteString;
    if (dataURI.split(',')[0].indexOf('base64') >= 0) {
      byteString = atob(dataURI.split(',')[1]);
    } else {
      byteString = decodeURIComponent(dataURI.split(',')[1]);
    }
    
    // Get the MIME type
    const mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    
    // Write the bytes of the string to a typed array
    const ia = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    
    return new Blob([ia], { type: mimeString });
  }
  
  /**
   * Delete an image from Firebase Storage
   * @param url The full URL of the image to delete
   */
  deleteImage(url: string): Promise<void> {
    try {
      // Extract the reference path from the URL
      const ref = this.storage.refFromURL(url);
      return ref.delete().toPromise();
    } catch (error) {
      console.error('Error deleting image:', error);
      return Promise.reject(error);
    }
  }
}