import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFireFunctions } from '@angular/fire/compat/functions';
import { Observable, from } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  constructor(
    private http: HttpClient,
    private auth: AngularFireAuth,
    private fns: AngularFireFunctions
  ) { }

  /**
   * Send booking confirmation email to user
   */
  sendBookingConfirmationEmail(
    userEmail: string,
    userName: string,
    propertyTitle: string,
    bookingDate: string,
    bookingTime: string
  ): Observable<any> {
    // Create the email data
    const emailData = {
      to: userEmail,
      subject: 'Your GoExploree Property Viewing Confirmation',
      template: 'booking_confirmation',
      data: {
        userName: userName,
        propertyTitle: propertyTitle,
        bookingDate: bookingDate,
        bookingTime: bookingTime,
        appName: 'GoExploree',
      }
    };
    
    // Log immediately to ensure quick response
    console.log('🔔 SENDING EMAIL NOTIFICATION:', emailData);
    
    // Try to get token but don't let it slow down the process
    return this.getIdToken().pipe(
      switchMap(token => {
        // We're not dependent on the token for our simulation
        // On a real Firebase implementation:
        // if (token && token !== 'timeout' && token !== 'no-user' && token !== 'error') {
        //   const callable = this.fns.httpsCallable('sendEmail');
        //   return callable(emailData);
        // }
        
        // For demo, always succeed quickly
        return from(Promise.resolve({ success: true, message: 'Email notification logged' }));
      })
    );
  }

  /**
   * Send property addition confirmation email to owner
   */
  sendPropertyAddedEmail(
    ownerEmail: string,
    ownerName: string,
    propertyTitle: string,
    propertyLocation: string
  ): Observable<any> {
    // Create the email data
    const emailData = {
      to: ownerEmail,
      subject: 'Your Property Has Been Listed on GoExploree',
      template: 'property_added',
      data: {
        ownerName: ownerName,
        propertyTitle: propertyTitle,
        propertyLocation: propertyLocation,
        appName: 'GoExploree',
      }
    };
    
    // Log immediately to ensure quick response
    console.log('🔔 SENDING EMAIL NOTIFICATION:', emailData);
    
    // Try to get token but don't let it slow down the process
    return this.getIdToken().pipe(
      switchMap(token => {
        // We're not dependent on the token for our simulation
        // On a real Firebase implementation:
        // if (token && token !== 'timeout' && token !== 'no-user' && token !== 'error') {
        //   const callable = this.fns.httpsCallable('sendEmail');
        //   return callable(emailData);
        // }
        
        // For demo, always succeed quickly
        return from(Promise.resolve({ success: true, message: 'Email notification logged' }));
      })
    );
  }

  /**
   * Get the current user's ID token
   * This implementation includes error handling and a timeout
   * to prevent hanging operations
   */
  private getIdToken(): Observable<string> {
    // Create a promise that resolves with null after 2 seconds
    const timeout = new Promise<string>((resolve) => {
      setTimeout(() => {
        console.log('ID token request timed out, using fallback');
        resolve('timeout'); // We'll use this as a signal to use fallback approach
      }, 2000);
    });

    // Try to get the token, but use timeout if it takes too long
    const tokenPromise = Promise.race([
      this.auth.currentUser.then(user => {
        if (user) {
          return user.getIdToken();
        } else {
          console.log('No user found, using fallback for email notification');
          return 'no-user';
        }
      }).catch(error => {
        console.error('Error getting auth token:', error);
        return 'error';
      }),
      timeout
    ]);

    return from(tokenPromise);
  }
}