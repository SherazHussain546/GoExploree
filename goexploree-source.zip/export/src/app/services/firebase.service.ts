import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  constructor() {
    // Initialize Firebase
    const app = initializeApp(environment.firebase);
    getAuth(app);
    getFirestore(app);
  }
}