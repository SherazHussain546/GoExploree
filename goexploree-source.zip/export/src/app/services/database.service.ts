import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class DatabaseService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) { }

  // Generic get request
  get<T>(endpoint: string): Observable<T> {
    const url = `${this.apiUrl}/${endpoint}`;
    console.log(`Making GET request to: ${url}`);
    return this.http.get<T>(url).pipe(
      catchError(error => {
        console.error(`Error in GET request to ${endpoint}:`, error);
        throw error;
      })
    );
  }

  // Generic post request
  post<T>(endpoint: string, data: any): Observable<T> {
    return this.http.post<T>(`${this.apiUrl}/${endpoint}`, data).pipe(
      catchError(error => {
        console.error(`Error in POST request to ${endpoint}:`, error);
        throw error;
      })
    );
  }

  // Generic put request
  put<T>(endpoint: string, data: any): Observable<T> {
    return this.http.put<T>(`${this.apiUrl}/${endpoint}`, data).pipe(
      catchError(error => {
        console.error(`Error in PUT request to ${endpoint}:`, error);
        throw error;
      })
    );
  }

  // Generic delete request
  delete<T>(endpoint: string): Observable<T> {
    return this.http.delete<T>(`${this.apiUrl}/${endpoint}`).pipe(
      catchError(error => {
        console.error(`Error in DELETE request to ${endpoint}:`, error);
        throw error;
      })
    );
  }
}