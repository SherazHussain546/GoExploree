import { Component, OnInit } from '@angular/core';
import { PropertyService } from '../services/property.service';
import { AuthService } from '../services/auth.service';
import { PropertyModel } from '../models/property.model';
import { Observable } from 'rxjs';
import { LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false
})
export class HomePage implements OnInit {
  properties: PropertyModel[] = [];
  featuredProperties: PropertyModel[] = [];
  isLoading = true;
  searchTerm = '';
  isLoggedIn = false;

  constructor(
    private propertyService: PropertyService,
    private authService: AuthService,
    private loadingController: LoadingController,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.isAuthenticated$.subscribe(isAuthenticated => {
      this.isLoggedIn = isAuthenticated;
    });
    
    this.loadProperties();
  }

  async loadProperties() {
    const loading = await this.loadingController.create({
      message: 'Loading properties...',
      spinner: 'bubbles',
    });
    await loading.present();

    // Set a timeout to dismiss the loading screen after 6 seconds if no response
    const timeout = setTimeout(() => {
      if (this.isLoading) {
        console.log('Properties loading timed out, dismissing loader');
        this.isLoading = false;
        loading.dismiss();
      }
    }, 6000);

    this.propertyService.getAllProperties().subscribe(
      (data) => {
        console.log('Properties loaded successfully:', data.length);
        // Cache regular properties for property details view
        this.propertyService.cacheSearchResults(data);
        this.properties = data;
        this.isLoading = false;
        loading.dismiss();
        clearTimeout(timeout);
      },
      (error) => {
        console.error('Error loading properties:', error);
        this.isLoading = false;
        loading.dismiss();
        clearTimeout(timeout);
      }
    );

    this.propertyService.getFeaturedProperties().subscribe(
      (data) => {
        console.log('Featured properties loaded:', data.length);
        // Also cache featured properties
        if (data && data.length > 0) {
          // Include featured properties in the main search cache
          this.propertyService.cacheSearchResults([...data]);
        }
        this.featuredProperties = data;
      },
      (error) => {
        console.error('Error loading featured properties:', error);
      }
    );
  }

  viewPropertyDetails(propertyId: number | string) {
    // Ensure we always use string IDs in URLs for consistency
    const idStr = propertyId.toString();
    console.log(`Navigating to property details with ID: ${idStr}`);
    this.router.navigate(['/property-details', idStr]);
  }

  addNewProperty() {
    this.router.navigate(['/add-property']);
  }

  // Force search to clear any cache or previous results
  async searchProperties() {
    // Clear any previous results completely
    this.properties = [];
    
    if (!this.searchTerm.trim()) {
      this.loadProperties();
      return;
    }

    // Immediately set loading state
    this.isLoading = true;
    
    try {
      // Create and present the loading indicator
      const loading = await this.loadingController.create({
        message: `Searching for properties in "${this.searchTerm}"...`,
        spinner: 'bubbles'
      });
      
      await loading.present();
      
      // Set a timeout to prevent endless loading
      const searchTimeout = setTimeout(() => {
        loading.dismiss();
        this.isLoading = false;
        console.log('Search timed out');
      }, 8000);
      
      console.log('🔍 Starting new search for:', this.searchTerm);
      
      // Execute the search
      this.propertyService.searchProperties(this.searchTerm)
        .subscribe(
          (results) => {
            // Clear timeout as we got results
            clearTimeout(searchTimeout);
            
            console.log(`✅ Found ${results.length} properties for "${this.searchTerm}"`);
            console.log('Search result locations:', results.map(p => p.location));
            
            // Cache search results for property details view
            this.propertyService.cacheSearchResults(results);
            
            // Update the UI with new results
            setTimeout(() => {
              // Empty the array first
              this.properties = [];
              
              // Then add new results after a small delay
              setTimeout(() => {
                this.properties = [...results];
                this.isLoading = false;
                loading.dismiss();
              }, 200);
            }, 200);
          },
          (error) => {
            clearTimeout(searchTimeout);
            console.error('❌ Error searching properties:', error);
            this.isLoading = false;
            loading.dismiss();
          }
        );
    } catch (error) {
      console.error('Error in search function:', error);
      this.isLoading = false;
    }
  }

  doRefresh(event: any) {
    this.loadProperties();
    setTimeout(() => {
      event.target.complete();
    }, 1000);
  }
}
