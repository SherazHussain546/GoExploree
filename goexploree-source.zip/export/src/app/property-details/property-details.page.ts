import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoadingController, ToastController, AlertController } from '@ionic/angular';
import { PropertyService } from '../services/property.service';
import { AuthService } from '../services/auth.service';
import { PropertyModel } from '../models/property.model';
import { environment } from '../../environments/environment';

declare var google: any;

@Component({
  selector: 'app-property-details',
  templateUrl: './property-details.page.html',
  styleUrls: ['./property-details.page.scss'],
  standalone: false
})
export class PropertyDetailsPage implements OnInit {
  @ViewChild('map', { static: false }) mapElement: ElementRef;
  map: any;
  propertyId: string;
  property: PropertyModel;
  isLoading = true;
  isLoggedIn = false;
  isOwner = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private propertyService: PropertyService,
    private authService: AuthService,
    private loadingController: LoadingController,
    private toastController: ToastController,
    private alertController: AlertController
  ) { }

  ngOnInit() {
    this.propertyId = this.route.snapshot.paramMap.get('id');
    
    this.authService.isAuthenticated$.subscribe(isAuthenticated => {
      this.isLoggedIn = isAuthenticated;
      this.checkIfOwner();
    });
    
    this.loadProperty();
  }

  async loadProperty() {
    if (!this.propertyId) {
      await this.showErrorToast('Property ID is required');
      this.router.navigate(['/home']);
      return;
    }

    const loading = await this.loadingController.create({
      message: 'Loading property details...',
      spinner: 'bubbles',
    });
    await loading.present();

    console.log(`PropertyDetailsPage: Loading property with ID: ${this.propertyId}`);
    
    // Try to load the property from both caches and Firebase
    this.propertyService.getPropertyById(this.propertyId).subscribe(
      (property) => {
        if (property) {
          console.log(`PropertyDetailsPage: Property loaded successfully: ${property.title}`);
          this.property = property;
          this.isLoading = false;
          this.checkIfOwner();
          
          loading.dismiss();
          
          // Load map after view is initialized
          setTimeout(() => {
            this.loadMap();
          }, 500);
        } else {
          console.error(`PropertyDetailsPage: Property not found with ID: ${this.propertyId}`);
          loading.dismiss();
          this.showErrorToast('Property not found');
          this.router.navigate(['/home']);
        }
      },
      (error) => {
        loading.dismiss();
        console.error('Error loading property:', error);
        this.showErrorToast('Failed to load property details');
        this.router.navigate(['/home']);
      }
    );
  }

  loadMap() {
    if (!this.mapElement) return;

    const latLng = new google.maps.LatLng(
      this.property.latitude,
      this.property.longitude
    );

    const mapOptions = {
      center: latLng,
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      disableDefaultUI: true
    };

    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);

    const marker = new google.maps.Marker({
      position: latLng,
      map: this.map,
      title: this.property.title,
      animation: google.maps.Animation.DROP
    });
  }

  async checkIfOwner() {
    if (this.isLoggedIn && this.property) {
      const currentUserId = await this.authService.getCurrentUserId();
      this.isOwner = currentUserId === this.property.ownerId;
    } else {
      this.isOwner = false;
    }
  }

  bookViewing() {
    this.router.navigate(['/book-viewing', this.propertyId]);
  }

  getDirections() {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${this.property.latitude},${this.property.longitude}`, '_blank');
  }

  async deleteProperty() {
    const alert = await this.alertController.create({
      header: 'Confirm Delete',
      message: 'Are you sure you want to delete this property? This action cannot be undone.',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Delete',
          handler: () => {
            this.confirmDelete();
          }
        }
      ]
    });

    await alert.present();
  }

  async confirmDelete() {
    const loading = await this.loadingController.create({
      message: 'Deleting property...',
      spinner: 'bubbles',
    });
    await loading.present();

    this.propertyService.deleteProperty(this.propertyId)
      .then(() => {
        loading.dismiss();
        this.showSuccessToast('Property deleted successfully');
        this.router.navigate(['/home']);
      })
      .catch(error => {
        loading.dismiss();
        console.error('Error deleting property:', error);
        this.showErrorToast('Failed to delete property');
      });
  }

  async showSuccessToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color: 'success'
    });
    toast.present();
  }

  async showErrorToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color: 'danger'
    });
    toast.present();
  }
}
