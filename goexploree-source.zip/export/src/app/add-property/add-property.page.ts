import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoadingController, ToastController } from '@ionic/angular';
import { PropertyService } from '../services/property.service';
import { AuthService } from '../services/auth.service';
import { EmailService } from '../services/email.service';
import { PropertyModel } from '../models/property.model';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

declare var google: any;

@Component({
  selector: 'app-add-property',
  templateUrl: './add-property.page.html',
  styleUrls: ['./add-property.page.scss'],
  standalone: false
})
export class AddPropertyPage implements OnInit {
  @ViewChild('map', { static: false }) mapElement: ElementRef;
  propertyForm: FormGroup;
  map: any;
  marker: any;
  isSubmitting = false;
  features: {name: string, selected: boolean}[] = [
    { name: 'Air Conditioning', selected: false },
    { name: 'Balcony', selected: false },
    { name: 'Dishwasher', selected: false },
    { name: 'Elevator', selected: false },
    { name: 'Furnished', selected: false },
    { name: 'Garden', selected: false },
    { name: 'Parking', selected: false },
    { name: 'Pet Friendly', selected: false },
    { name: 'Swimming Pool', selected: false },
    { name: 'Wifi', selected: false }
  ];

  selectedImage: File | null = null;
  selectedImageUrl: SafeUrl | null = null;
  formSubmitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private propertyService: PropertyService,
    private authService: AuthService,
    private emailService: EmailService,
    private router: Router,
    private loadingController: LoadingController,
    private toastController: ToastController,
    private sanitizer: DomSanitizer
  ) {
    this.createForm();
  }

  ngOnInit() {}

  ionViewDidEnter() {
    this.loadMap();
  }

  createForm() {
    this.propertyForm = this.formBuilder.group({
      title: ['', [Validators.required, Validators.minLength(5)]],
      description: ['', [Validators.required, Validators.minLength(20)]],
      price: ['', [Validators.required, Validators.min(1)]],
      location: ['', Validators.required],
      imageUrl: [''], // Changed to optional as we'll handle image separately
      bedrooms: ['', [Validators.required, Validators.min(1)]],
      bathrooms: ['', [Validators.required, Validators.min(1)]],
      area: ['', [Validators.required, Validators.min(1)]],
      latitude: ['', Validators.required],
      longitude: ['', Validators.required]
    });
  }
  
  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedImage = input.files[0];
      // Create a preview URL
      const reader = new FileReader();
      reader.onload = () => {
        this.selectedImageUrl = this.sanitizer.bypassSecurityTrustUrl(reader.result as string);
      };
      reader.readAsDataURL(this.selectedImage);
    }
  }
  
  removeImage() {
    this.selectedImage = null;
    this.selectedImageUrl = null;
  }

  loadMap() {
    // Default location (center of the city)
    const latLng = new google.maps.LatLng(40.7128, -74.0060);
    
    const mapOptions = {
      center: latLng,
      zoom: 13,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      disableDefaultUI: false
    };
    
    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    
    this.marker = new google.maps.Marker({
      position: latLng,
      map: this.map,
      title: 'Property Location',
      draggable: true,
      animation: google.maps.Animation.DROP
    });
    
    // Update form on marker drag
    google.maps.event.addListener(this.marker, 'dragend', () => {
      const position = this.marker.getPosition();
      this.propertyForm.patchValue({
        latitude: position.lat(),
        longitude: position.lng()
      });
      
      // Get address from coordinates
      this.getAddressFromCoordinates(position.lat(), position.lng());
    });
    
    // Add click listener to map
    google.maps.event.addListener(this.map, 'click', (event) => {
      this.marker.setPosition(event.latLng);
      this.propertyForm.patchValue({
        latitude: event.latLng.lat(),
        longitude: event.latLng.lng()
      });
      
      // Get address from coordinates
      this.getAddressFromCoordinates(event.latLng.lat(), event.latLng.lng());
    });
  }
  
  // Use Geocoder to get address from coordinates
  getAddressFromCoordinates(lat: number, lng: number) {
    const geocoder = new google.maps.Geocoder();
    const latlng = { lat, lng };
    
    geocoder.geocode({ location: latlng }, (results, status) => {
      if (status === 'OK' && results[0]) {
        this.propertyForm.patchValue({
          location: results[0].formatted_address
        });
      }
    });
  }

  // Search for location and center map
  searchLocation() {
    const geocoder = new google.maps.Geocoder();
    const address = this.propertyForm.get('location').value;
    
    if (!address) return;
    
    geocoder.geocode({ address }, (results, status) => {
      if (status === 'OK' && results[0]) {
        const position = results[0].geometry.location;
        
        this.map.setCenter(position);
        this.marker.setPosition(position);
        
        this.propertyForm.patchValue({
          latitude: position.lat(),
          longitude: position.lng()
        });
      }
    });
  }

  toggleFeature(index: number) {
    this.features[index].selected = !this.features[index].selected;
  }
  
  // Helper method to convert image file to base64 string
  private convertImageToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64String = reader.result as string;
        
        // Compress the image to reduce size if needed
        this.compressImage(base64String)
          .then(compressedImage => resolve(compressedImage))
          .catch(error => reject(error));
      };
      reader.onerror = (error) => {
        reject(error);
      };
      reader.readAsDataURL(file);
    });
  }
  
  // Helper method to compress images
  private compressImage(base64Image: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        // Create a canvas to draw the compressed image
        const canvas = document.createElement('canvas');
        
        // Calculate new dimensions (max width 800px)
        let width = img.width;
        let height = img.height;
        const maxWidth = 800;
        
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        
        canvas.width = width;
        canvas.height = height;
        
        // Draw the image on the canvas
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        
        // Get the compressed image (adjust quality as needed)
        const compressedImage = canvas.toDataURL('image/jpeg', 0.7);
        resolve(compressedImage);
      };
      
      img.onerror = (error) => reject(error);
      img.src = base64Image;
    });
  }

  async submitProperty() {
    this.formSubmitted = true;
    
    if (this.propertyForm.invalid) {
      this.markFormGroupTouched(this.propertyForm);
      return;
    }
    
    if (!this.selectedImage) {
      this.showErrorToast('Please select an image for the property');
      return;
    }

    this.isSubmitting = true;
    const loading = await this.loadingController.create({
      message: 'Adding your property...',
      spinner: 'bubbles',
    });
    await loading.present();

    try {
      // Convert the image file to a base64 string
      const imageUrl = await this.convertImageToBase64(this.selectedImage);
      
      // Get selected features
      const selectedFeatures = this.features
        .filter(feature => feature.selected)
        .map(feature => feature.name);

      // Get user data
      const userData = this.authService.getUserData();
      
      if (!userData) {
        loading.dismiss();
        this.showErrorToast('User authentication failed');
        return;
      }

      const newProperty: Omit<PropertyModel, 'id'> = {
        ...this.propertyForm.value,
        imageUrl, // Use the base64 image data
        features: selectedFeatures,
        ownerId: userData.uid,
        ownerName: userData.displayName || userData.email,
        ownerEmail: userData.email
      };

      console.log('Submitting property to Firestore...');
      try {
        const docRef = await this.propertyService.addProperty(newProperty);
        console.log('Property added successfully with ID:', docRef.id);
        
        // Dismiss loading first to improve UI responsiveness
        loading.dismiss();
        this.showSuccessToast('Property added successfully! A confirmation email will be sent shortly.');
        
        // Navigate to property details immediately
        const propertyId = docRef.id;
        this.router.navigate(['/property-details', propertyId]);
        
        // Send email notification for property addition asynchronously
        // This happens in the background and doesn't block UI
        setTimeout(() => {
          this.emailService.sendPropertyAddedEmail(
            userData.email,
            userData.displayName || userData.email,
            this.propertyForm.value.title,
            this.propertyForm.value.location
          ).subscribe(
            () => {
              console.log('Property added email sent successfully');
            },
            (error) => {
              console.error('Error sending property added email:', error);
            }
          );
        }, 100); // Small delay to prioritize UI responsiveness
      } catch (firestoreError) {
        console.error('Firestore error when adding property:', firestoreError);
        
        // More detailed error handling
        let errorMsg = 'Failed to add property. ';
        
        if (firestoreError.code) {
          // Handle specific Firebase error codes
          switch(firestoreError.code) {
            case 'permission-denied':
              errorMsg += 'Permission denied. Please check your login status.';
              break;
            case 'resource-exhausted':
              errorMsg += 'The image might be too large. Please try a smaller image.';
              break;
            default:
              errorMsg += `Error code: ${firestoreError.code}`;
          }
        } else {
          errorMsg += 'Please try again with a smaller image or fewer details.';
        }
        
        loading.dismiss();
        this.isSubmitting = false;
        this.showErrorToast(errorMsg);
      }
    } catch (error) {
      loading.dismiss();
      this.isSubmitting = false;
      console.error('Error in property submission process:', error);
      this.showErrorToast('Failed to process your property. Please try again.');
    }
  }

  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  async showSuccessToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'bottom',
      color: 'success',
      buttons: [
        {
          text: 'OK',
          role: 'cancel'
        }
      ]
    });
    toast.present();
  }

  async showErrorToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'bottom',
      color: 'danger',
      buttons: [
        {
          text: 'OK',
          role: 'cancel'
        }
      ]
    });
    toast.present();
  }
}
