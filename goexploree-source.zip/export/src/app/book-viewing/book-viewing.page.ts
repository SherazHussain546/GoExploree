import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoadingController, ToastController } from '@ionic/angular';
import { PropertyService } from '../services/property.service';
import { BookingService } from '../services/booking.service';
import { AuthService } from '../services/auth.service';
import { EmailService } from '../services/email.service';
import { PropertyModel } from '../models/property.model';
import { BookingModel } from '../models/booking.model';

@Component({
  selector: 'app-book-viewing',
  templateUrl: './book-viewing.page.html',
  styleUrls: ['./book-viewing.page.scss'],
  standalone: false
})
export class BookViewingPage implements OnInit {
  bookingForm: FormGroup;
  propertyId: string;
  property: PropertyModel;
  propertyIdNumber: number;
  isLoading = true;
  isSubmitting = false;
  minDate: string;
  maxDate: string;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private propertyService: PropertyService,
    private bookingService: BookingService,
    private authService: AuthService,
    private emailService: EmailService,
    private loadingController: LoadingController,
    private toastController: ToastController
  ) {
    // Set min date to today and max date to 3 months from now
    const today = new Date();
    const threeMonthsLater = new Date();
    threeMonthsLater.setMonth(today.getMonth() + 3);
    
    this.minDate = today.toISOString().split('T')[0];
    this.maxDate = threeMonthsLater.toISOString().split('T')[0];
    
    this.createForm();
  }

  ngOnInit() {
    this.propertyId = this.route.snapshot.paramMap.get('propertyId');
    
    if (!this.propertyId) {
      this.showErrorToast('Property ID is missing');
      this.router.navigate(['/home']);
      return;
    }
    
    // Convert to number for database operations
    this.propertyIdNumber = parseInt(this.propertyId) || 0; // Ensure it's a valid number
    
    this.loadProperty();
  }

  createForm() {
    // Get current user data
    const userData = this.authService.getUserData();
    
    this.bookingForm = this.formBuilder.group({
      date: ['', Validators.required],
      time: ['', Validators.required],
      userName: [userData?.displayName || '', Validators.required],
      userEmail: [userData?.email || '', [Validators.required, Validators.email]],
      userPhone: ['', [Validators.required, Validators.pattern('^[0-9]{10,15}$')]],
      notes: ['']
    });
  }

  async loadProperty() {
    const loading = await this.loadingController.create({
      message: 'Loading property details...',
      spinner: 'bubbles',
    });
    await loading.present();

    this.propertyService.getPropertyById(this.propertyId).subscribe(
      (property) => {
        if (property) {
          this.property = property;
          this.isLoading = false;
          loading.dismiss();
        } else {
          loading.dismiss();
          this.showErrorToast('Property not found');
          this.router.navigate(['/home']);
        }
      },
      (error) => {
        loading.dismiss();
        console.error('Error loading property:', error);
        this.showErrorToast('Failed to load property details');
        this.router.navigate(['/home']);
      }
    );
  }

  async bookViewing() {
    if (this.bookingForm.invalid) {
      this.markFormGroupTouched(this.bookingForm);
      return;
    }

    this.isSubmitting = true;
    
    // Show a shorter loading spinner (max 0.8 seconds)
    const loading = await this.loadingController.create({
      message: 'Booking your viewing...',
      spinner: 'bubbles',
      duration: 800 // Auto-dismiss after 0.8 second max
    });
    await loading.present();

    // Get user ID immediately instead of waiting for async operation
    let userId = '';
    try {
      userId = this.authService.getUserData()?.uid || '';
      if (!userId) {
        const fetchedId = await this.authService.getCurrentUserId();
        userId = fetchedId || '';
      }
    } catch (error) {
      console.error('Error getting user ID:', error);
    }
    
    if (!userId) {
      loading.dismiss();
      this.showErrorToast('Authentication error');
      return;
    }

    // Create booking data object
    const bookingData: Omit<BookingModel, 'id'> = {
      propertyId: this.propertyIdNumber,
      propertyTitle: this.property.title,
      propertyImage: this.property.imageUrl,
      userId: userId,
      userName: this.bookingForm.value.userName,
      userEmail: this.bookingForm.value.userEmail,
      userPhone: this.bookingForm.value.userPhone,
      date: new Date(this.bookingForm.value.date),
      time: this.bookingForm.value.time,
      notes: this.bookingForm.value.notes || '',
      status: 'pending'
    };

    // Store booking in localStorage as a fallback
    try {
      // Generate a temporary local ID
      const tempId = 'local-' + Date.now();
      
      // Store the booking data in localStorage
      const localBooking = { ...bookingData, id: tempId };
      const existingBookings = localStorage.getItem('pendingBookings');
      const bookingsArray = existingBookings ? JSON.parse(existingBookings) : [];
      bookingsArray.push(localBooking);
      localStorage.setItem('pendingBookings', JSON.stringify(bookingsArray));
      
      console.log('Booking saved to local storage:', localBooking);
      
      // Dismiss loading immediately after local storage succeeds
      loading.dismiss();
      
      // Show success toast
      this.showSuccessToast('Viewing booked successfully! A confirmation email will be sent shortly.');
      
      // Navigate to property details page immediately
      this.router.navigate(['/property-details', this.propertyId]);
      
      // Try to store in Firebase asynchronously (don't wait for result)
      setTimeout(() => {
        this.bookingService.bookViewing(bookingData)
          .then(result => {
            console.log('Booking successfully saved to Firebase:', result);
            
            // Remove from local storage if Firebase save succeeded
            const updatedBookings = bookingsArray.filter(b => b.id !== tempId);
            localStorage.setItem('pendingBookings', JSON.stringify(updatedBookings));
          })
          .catch(error => {
            console.error('Firebase booking error (using local fallback):', error);
          });
      }, 10);
      
      // Send email notification asynchronously (don't wait for result)
      const formattedDate = new Date(this.bookingForm.value.date).toLocaleDateString();
      setTimeout(() => {
        this.emailService.sendBookingConfirmationEmail(
          this.bookingForm.value.userEmail,
          this.bookingForm.value.userName,
          this.property.title,
          formattedDate,
          this.bookingForm.value.time
        ).subscribe(
          () => console.log('Booking confirmation email sent successfully'),
          (error) => console.error('Error sending booking confirmation email:', error)
        );
      }, 10);
      
    } catch (error) {
      // Handle errors with local storage
      loading.dismiss();
      this.isSubmitting = false;
      console.error('Error saving booking:', error);
      this.showErrorToast('Failed to save booking. Please try again.');
    }
  }

  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  async showSuccessToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'bottom',
      color: 'success',
      buttons: [
        {
          text: 'OK',
          role: 'cancel'
        }
      ]
    });
    toast.present();
  }

  async showErrorToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'bottom',
      color: 'danger',
      buttons: [
        {
          text: 'OK',
          role: 'cancel'
        }
      ]
    });
    toast.present();
  }
}
