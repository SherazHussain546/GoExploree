export interface UserModel {
  id?: number;
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  phoneNumber?: string;
  isOwner?: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}
