export interface PropertyModel {
  id: number;
  title: string;
  description: string;
  price: number;
  location: string;
  imageUrl: string;
  latitude: number | string;
  longitude: number | string;
  bedrooms: number;
  bathrooms: number;
  area: number;  // square feet or meters
  features: string[];
  ownerId: string;
  ownerName: string;
  ownerEmail: string;
  createdAt?: Date;
  updatedAt?: Date;
}
