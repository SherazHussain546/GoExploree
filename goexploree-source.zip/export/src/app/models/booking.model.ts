export interface BookingModel {
  id: string | number;  // Allow both string (FirebaseID or localID) and number (PostgreSQL ID)
  propertyId: number;
  propertyTitle: string;
  propertyImage: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  date: Date;
  time: string;
  notes: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  createdAt?: Date;
  updatedAt?: Date;
  // Optional field to track if this is a local booking (not yet saved to Firebase)
  isLocal?: boolean;
}
