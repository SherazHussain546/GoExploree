import { Component } from '@angular/core';
import { Platform, ToastController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AuthService } from './services/auth.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: false
})
export class AppComponent {
  isLoggedIn = false;
  authSubscription: Subscription;
  
  public appPages = [
    { title: 'Explore Properties', url: '/home', icon: 'search' },
    { title: 'Add Property', url: '/add-property', icon: 'add-circle', requiresAuth: true },
    { title: 'My Profile', url: '/profile', icon: 'person', requiresAuth: true },
  ];

  // Track if we're running as a mobile app
  isMobileApp: boolean = false;
  // Track back button presses for exit confirmation
  lastTimeBackPressed: number = 0;
  
  constructor(
    private platform: Platform,
    private authService: AuthService,
    private router: Router,
    private toastController: ToastController
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Subscribe to auth state changes
      this.authSubscription = this.authService.isAuthenticated$.subscribe(isAuthenticated => {
        this.isLoggedIn = isAuthenticated;
      });
      
      // Detect if we're running as a mobile app rather than in browser
      this.isMobileApp = this.platform.is('capacitor') || this.platform.is('cordova');
      
      // Apply mobile optimizations class to the body if on a mobile device
      document.body.classList.toggle('mobile-optimized', this.isMobileApp);
      
      // Add iOS/Android specific classes
      if (this.platform.is('ios')) {
        document.body.classList.add('ios-optimized');
      } else if (this.platform.is('android')) {
        document.body.classList.add('android-optimized');
      }
      
      // Setup hardware back button handling for Android
      if (this.isMobileApp) {
        this.setupBackButtonHandling();
        
        // Register for app state changes
        this.setupAppLifecycle();
      }
    });
  }
  
  /**
   * Setup back button handling for Android devices
   */
  private setupBackButtonHandling() {
    this.platform.backButton.subscribeWithPriority(10, async () => {
      // Check if we're at the root of the navigation stack
      if (this.router.url === '/home' || this.router.url === '/') {
        // If back button is pressed twice within 2 seconds, exit the app
        if (this.lastTimeBackPressed && new Date().getTime() - this.lastTimeBackPressed < 2000) {
          // When in native app, this would exit the app, but in browser it just logs
          console.log('Exit app requested');
          // In a real mobile app, we would use: App.exitApp();
        } else {
          const toast = await this.toastController.create({
            message: 'Press back again to exit app',
            duration: 2000,
            position: 'bottom'
          });
          await toast.present();
          this.lastTimeBackPressed = new Date().getTime();
        }
      } else {
        // Otherwise just navigate back
        window.history.back();
      }
    });
  }
  
  /**
   * Handle app lifecycle events (pause, resume)
   */
  private setupAppLifecycle() {
    // In a native app build, we would use the Capacitor App plugin to listen for app state changes
    // For web preview, we'll use the browser's visibility API as a simulation
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        // App resumed from background
        console.log('App resumed from background');
        
        // Check authentication status when app comes back from background
        this.authService.checkAuthState();
      } else {
        // App sent to background
        console.log('App sent to background');
        
        // Save any necessary app state here
        this.saveAppState();
      }
    });
  }
  
  /**
   * Save app state when app is sent to background
   */
  private saveAppState() {
    // Save any pending data or state
    // This could include saving search filters, unsaved form data, etc.
    console.log('Saving app state before going to background');
    
    // For example, we might want to persist the search state in localStorage
    try {
      const currentUrl = this.router.url;
      localStorage.setItem('lastRoute', currentUrl);
    } catch (error) {
      console.error('Error saving app state:', error);
    }
  }

  logout() {
    this.authService.signOut().then(() => {
      this.router.navigateByUrl('/home');
    });
  }

  login() {
    this.router.navigateByUrl('/login');
  }

  ngOnDestroy() {
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
  }
}
