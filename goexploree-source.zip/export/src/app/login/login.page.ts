import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { LoadingController, ToastController } from '@ionic/angular';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false
})
export class LoginPage implements OnInit {
  loginForm: FormGroup;
  returnUrl: string;
  isLoading = false;
  firebaseConfigured = false;
  
  constructor(
    private formBuilder: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private loadingController: LoadingController,
    private toastController: ToastController
  ) {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit() {
    // Get return URL from route parameters or default to '/home'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
    
    // Check if Firebase is configured
    this.checkFirebaseConfiguration();
    
    // Redirect if already logged in
    this.authService.isAuthenticated$.subscribe(isAuthenticated => {
      if (isAuthenticated) {
        this.router.navigate([this.returnUrl]);
      }
    });
  }
  
  /**
   * Check if Firebase configuration is properly loaded
   */
  checkFirebaseConfiguration() {
    const win = window as any;
    this.firebaseConfigured = !!(
      win.env?.VITE_FIREBASE_API_KEY && 
      win.env?.VITE_FIREBASE_PROJECT_ID &&
      win.env?.VITE_FIREBASE_APP_ID
    );
    
    console.log('Firebase configuration status:', this.firebaseConfigured ? 'Configured' : 'Not configured');
    if (!this.firebaseConfigured) {
      console.warn('Firebase configuration missing or incomplete. Google authentication might not work properly.');
    }
  }

  async login() {
    if (this.loginForm.invalid) {
      return;
    }

    this.isLoading = true;
    const loading = await this.loadingController.create({
      message: 'Logging in...',
      spinner: 'bubbles',
    });
    await loading.present();

    const { email, password } = this.loginForm.value;

    this.authService.signIn(email, password)
      .then(result => {
        loading.dismiss();
        this.router.navigateByUrl(this.returnUrl);
      })
      .catch(error => {
        loading.dismiss();
        this.isLoading = false;
        this.showErrorToast(this.getErrorMessage(error.code));
      });
  }

  async loginWithGoogle() {
    try {
      this.isLoading = true;
      const loading = await this.loadingController.create({
        message: 'Logging in with Google...',
        spinner: 'bubbles',
      });
      await loading.present();

      console.log('Starting Google login process');
      
      // Check if Firebase environment variables are loaded
      const win = window as any;
      if (!win.env?.VITE_FIREBASE_API_KEY) {
        console.warn('Firebase API key is missing!');
        loading.dismiss();
        this.isLoading = false;
        this.showErrorToast('Firebase configuration is missing. Please try again later.');
        return;
      }
      
      // Proceed with Google login
      const result = await this.authService.signInWithGoogle();
      console.log('Google login successful:', result);
      loading.dismiss();
      this.router.navigateByUrl(this.returnUrl);
    } catch (error) {
      console.error('Google login error:', error);
      this.isLoading = false;
      
      // Display appropriate error message
      if (error.code) {
        this.showErrorToast(this.getErrorMessage(error.code));
      } else {
        this.showErrorToast('An error occurred during Google sign-in. Please try again.');
      }
      
      const loading = await this.loadingController.getTop();
      if (loading) {
        loading.dismiss();
      }
    }
  }

  async showErrorToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 3000,
      position: 'bottom',
      color: 'danger',
      buttons: [
        {
          text: 'OK',
          role: 'cancel'
        }
      ]
    });
    toast.present();
  }

  getErrorMessage(errorCode: string): string {
    switch (errorCode) {
      case 'auth/user-not-found':
        return 'User not found. Please check your email or register.';
      case 'auth/wrong-password':
        return 'Invalid password. Please try again.';
      case 'auth/invalid-email':
        return 'Invalid email format.';
      case 'auth/user-disabled':
        return 'This account has been disabled.';
      case 'auth/too-many-requests':
        return 'Too many unsuccessful login attempts. Please try again later.';
      default:
        return 'An error occurred during login. Please try again.';
    }
  }

  goToRegister() {
    this.router.navigate(['/register'], { queryParams: { returnUrl: this.returnUrl } });
  }
}
