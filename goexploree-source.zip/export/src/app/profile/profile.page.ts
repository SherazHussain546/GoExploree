import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, LoadingController, ToastController } from '@ionic/angular';
import { AuthService } from '../services/auth.service';
import { PropertyService } from '../services/property.service';
import { BookingService } from '../services/booking.service';
import { UserModel } from '../models/user.model';
import { PropertyModel } from '../models/property.model';
import { BookingModel } from '../models/booking.model';
import { combineLatest, Observable, of } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
  standalone: false
})
export class ProfilePage implements OnInit {
  user: UserModel;
  segment = 'properties';
  properties: PropertyModel[] = [];
  bookings: BookingModel[] = [];
  isLoadingProperties = true;
  isLoadingBookings = true;

  constructor(
    private authService: AuthService,
    private propertyService: PropertyService,
    private bookingService: BookingService,
    private router: Router,
    private alertController: AlertController,
    private loadingController: LoadingController,
    private toastController: ToastController
  ) { }

  ngOnInit() {
    this.user = this.authService.getUserData();
    
    if (!this.user) {
      this.router.navigate(['/login']);
      return;
    }
    
    this.loadUserProperties();
    this.loadUserBookings();
  }

  segmentChanged(event: any) {
    this.segment = event.detail.value;
  }

  loadUserProperties() {
    this.isLoadingProperties = true;
    
    this.propertyService.getPropertiesByUserId(this.user.uid).subscribe(
      (properties) => {
        this.properties = properties;
        this.isLoadingProperties = false;
      },
      (error) => {
        console.error('Error loading properties:', error);
        this.isLoadingProperties = false;
        this.showErrorToast('Failed to load your properties');
      }
    );
  }

  loadUserBookings() {
    this.isLoadingBookings = true;
    
    this.bookingService.getUserBookings().subscribe(
      (bookings) => {
        this.bookings = bookings;
        this.isLoadingBookings = false;
      },
      (error) => {
        console.error('Error loading bookings:', error);
        this.isLoadingBookings = false;
        this.showErrorToast('Failed to load your bookings');
      }
    );
  }

  viewPropertyDetails(propertyId: number) {
    this.router.navigate(['/property-details', propertyId.toString()]);
  }

  async cancelBooking(booking: BookingModel) {
    const alert = await this.alertController.create({
      header: 'Cancel Booking',
      message: 'Are you sure you want to cancel this viewing?',
      buttons: [
        {
          text: 'No',
          role: 'cancel'
        },
        {
          text: 'Yes, Cancel',
          handler: () => {
            this.confirmCancelBooking(booking.id);
          }
        }
      ]
    });

    await alert.present();
  }

  async confirmCancelBooking(bookingId: string | number) {
    const loading = await this.loadingController.create({
      message: 'Cancelling booking...',
      spinner: 'bubbles',
    });
    await loading.present();

    // First check if this is a local booking
    if (typeof bookingId === 'string' && bookingId.startsWith('local-')) {
      // Handle local booking cancellation
      this.bookingService.removeBookingFromLocalStorage(bookingId);
      loading.dismiss();
      this.showSuccessToast('Booking cancelled successfully');
      return;
    }

    // Otherwise proceed with Firebase cancellation
    this.bookingService.cancelBooking(String(bookingId))
      .then(() => {
        loading.dismiss();
        this.showSuccessToast('Booking cancelled successfully');
      })
      .catch(error => {
        loading.dismiss();
        console.error('Error cancelling booking:', error);
        this.showErrorToast('Failed to cancel booking');
      });
  }

  getBookingStatusColor(status: string): string {
    switch (status) {
      case 'pending':
        return 'warning';
      case 'confirmed':
        return 'success';
      case 'cancelled':
        return 'danger';
      case 'completed':
        return 'medium';
      default:
        return 'medium';
    }
  }

  formatDate(date: Date | any): string {
    if (!date) return '';
    
    if (typeof date === 'string') {
      date = new Date(date);
    } else if (date.toDate) {
      // Handle Firestore Timestamp
      date = date.toDate();
    }
    
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }

  async logout() {
    const alert = await this.alertController.create({
      header: 'Logout',
      message: 'Are you sure you want to logout?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel'
        },
        {
          text: 'Logout',
          handler: () => {
            this.authService.signOut().then(() => {
              this.router.navigate(['/home']);
            });
          }
        }
      ]
    });

    await alert.present();
  }

  addNewProperty() {
    this.router.navigate(['/add-property']);
  }

  async showSuccessToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color: 'success'
    });
    toast.present();
  }

  async showErrorToast(message: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      position: 'bottom',
      color: 'danger'
    });
    toast.present();
  }

  doRefresh(event: any) {
    if (this.segment === 'properties') {
      this.loadUserProperties();
    } else {
      this.loadUserBookings();
    }
    
    setTimeout(() => {
      event.target.complete();
    }, 1000);
  }
}
